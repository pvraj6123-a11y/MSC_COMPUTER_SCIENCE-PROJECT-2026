"""
Flask application for fake news detection.
Provides REST API and web dashboard for interactive predictions.
"""

import logging
import os
from pathlib import Path
from functools import wraps

from flask import Flask, render_template, request, jsonify
import config
from src.predict import FakeNewsPredictorEnsemble
from src.utils import setup_logging, check_models_exist

# Setup logging
setup_logging(logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = config.FLASK_CONFIG["max_content_length"]

# Global predictor instance
predictor = None
models_loaded = False


def require_models(f):
    """Decorator to check if models are loaded."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        global models_loaded
        if not models_loaded:
            return (
                jsonify(
                    {
                        "success": False,
                        "error": "Models not loaded. Run 'python train_all.py' first.",
                    }
                ),
                503,
            )
        return f(*args, **kwargs)

    return decorated_function


def initialize_predictor() -> bool:
    """
    Initialize the predictor and load models.

    Returns:
        True if successful, False otherwise
    """
    global predictor, models_loaded

    try:
        if not check_models_exist():
            logger.warning("Not all models found")
            return False

        predictor = FakeNewsPredictorEnsemble()
        if not predictor.load_all_models():
            logger.error("Failed to load one or more models")
            return False

        models_loaded = True
        logger.info("All models loaded successfully")
        return True

    except Exception as e:
        logger.error(f"Error initializing predictor: {e}", exc_info=True)
        return False


# Routes


@app.route("/")
def dashboard():
    """Serve main dashboard."""
    if not models_loaded:
        return render_template("index.html", models_loaded=False)
    return render_template("index.html", models_loaded=True)


@app.route("/api/health", methods=["GET"])
def health():
    """Health check endpoint."""
    return jsonify({"status": "healthy", "models_loaded": models_loaded}), 200


@app.route("/api/predict", methods=["POST"])
@require_models
def predict():
    """
    Make predictions on input text.

    Request JSON:
    {
        "text": "News article text"
    }

    Response JSON:
    {
        "success": true,
        "input_text": "...",
        "predictions": {
            "Logistic Regression": {"label": "REAL", "confidence": 0.95},
            "BiLSTM": {"label": "REAL", "confidence": 0.89},
            "DistilBERT": {"label": "FAKE", "confidence": 0.73}
        },
        "majority_prediction": "REAL"
    }
    """
    try:
        # Validate request
        if not request.is_json:
            return (
                jsonify({"success": False, "error": "Request must be JSON"}),
                400,
            )

        data = request.get_json()
        if "text" not in data:
            return (
                jsonify({"success": False, "error": "Missing 'text' field"}),
                400,
            )

        text = data["text"].strip()

        # Validate input
        if not text:
            return (
                jsonify({"success": False, "error": "Text cannot be empty"}),
                400,
            )

        if len(text) > config.API_CONFIG["max_text_length"]:
            return (
                jsonify(
                    {
                        "success": False,
                        "error": f"Text exceeds maximum length of {config.API_CONFIG['max_text_length']} characters",
                    }
                ),
                400,
            )

        # Make predictions
        logger.info(f"Making predictions for text of length {len(text)}")
        results = predictor.predict_all(text)

        return jsonify({"success": True, **results}), 200

    except Exception as e:
        logger.error(f"Prediction error: {e}", exc_info=True)
        return (
            jsonify(
                {
                    "success": False,
                    "error": "An error occurred during prediction",
                }
            ),
            500,
        )


@app.route("/api/model-info", methods=["GET"])
def model_info():
    """Get information about available models."""
    from src.utils import get_model_info

    info = get_model_info()
    return jsonify({"models": info}), 200


@app.route("/api/results", methods=["GET"])
def results():
    """Get evaluation results if available."""
    try:
        results_data = {}

        # Check for metrics CSV
        if config.RESULTS_PATHS["metrics_csv"].exists():
            import pandas as pd

            df = pd.read_csv(config.RESULTS_PATHS["metrics_csv"])
            results_data["metrics"] = df.to_dict("records")

        # Check for plot files
        results_data["plots"] = {}
        plot_files = {
            "comparison": config.RESULTS_PATHS["model_comparison"],
            "training_history": config.RESULTS_PATHS["training_history"],
            "confusion_logistic": config.RESULTS_PATHS["confusion_logistic"],
            "confusion_bilstm": config.RESULTS_PATHS["confusion_bilstm"],
            "confusion_distilbert": config.RESULTS_PATHS["confusion_distilbert"],
            "efficiency": config.RESULTS_PATHS["efficiency_png"],
        }

        for name, path in plot_files.items():
            if path.exists():
                results_data["plots"][name] = f"/results/{path.name}"

        return jsonify(results_data), 200

    except Exception as e:
        logger.error(f"Error retrieving results: {e}")
        return (
            jsonify(
                {
                    "error": "Results not available yet. Run 'python train_all.py' first."
                }
            ),
            404,
        )


@app.route("/results/<filename>", methods=["GET"])
def serve_results(filename):
    """Serve result files."""
    from flask import send_file

    try:
        file_path = config.RESULTS_DIR / filename
        if not file_path.exists():
            return jsonify({"error": "File not found"}), 404

        return send_file(file_path, mimetype="image/png")

    except Exception as e:
        logger.error(f"Error serving file: {e}")
        return jsonify({"error": "Error serving file"}), 500


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def server_error(error):
    """Handle 500 errors."""
    return jsonify({"error": "Internal server error"}), 500


def main():
    """Main entry point."""
    logger.info("Initializing Fake News Detection API...")

    if not initialize_predictor():
        logger.warning("Models not loaded. Dashboard will show initialization message.")

    logger.info(f"Starting Flask server at {config.FLASK_CONFIG['host']}:{config.FLASK_CONFIG['port']}")
    logger.info("Open http://localhost:5000 in your browser")

    app.run(
        host=config.FLASK_CONFIG["host"],
        port=config.FLASK_CONFIG["port"],
        debug=config.FLASK_CONFIG["debug"],
    )


if __name__ == "__main__":
    main()
