"""
Master training script for all fake news detection models.
Orchestrates data loading, preprocessing, and training of all three models.
"""

import logging
import sys
from pathlib import Path
from typing import Dict, Any

import config
from src.data_loader import FakeNewsDataLoader
from src.train_logistic import train_logistic_model
from src.train_bilstm import train_bilstm_model
from src.train_distilbert import train_distilbert_model
from src.evaluate import generate_all_evaluation_plots
from src.utils import setup_logging, verify_dataset_format, create_results_summary

logger = logging.getLogger(__name__)


def main():
    """
    Complete training pipeline for all models.
    """
    # Setup logging
    setup_logging(logging.INFO)
    logger.info("=" * 80)
    logger.info("FAKE NEWS DETECTION - MODEL TRAINING")
    logger.info("=" * 80)

    try:
        # 1. Verify dataset exists
        logger.info("\nStep 1: Verifying dataset...")
        if not verify_dataset_format(config.DATA_DIR):
            logger.error(
                f"No valid dataset found in {config.DATA_DIR}. "
                f"Please place Fake.csv and True.csv (or a single CSV) in the data directory."
            )
            return 1

        # 2. Load and preprocess dataset
        logger.info("\nStep 2: Loading and preprocessing dataset...")
        data_loader = FakeNewsDataLoader(
            data_dir=config.DATA_DIR,
            random_state=config.RANDOM_STATE,
            train_size=config.DATASET_CONFIG["train_size"],
            val_size=config.DATASET_CONFIG["val_size"],
            test_size=config.DATASET_CONFIG["test_size"],
            sample_size=config.DEBUG_SAMPLE_SIZE,
        )

        train_df, val_df, test_df = data_loader.load_and_split()
        logger.info(
            f"Dataset split - Train: {len(train_df)}, "
            f"Val: {len(val_df)}, Test: {len(test_df)}"
        )

        # 3. Train Logistic Regression
        logger.info("\nStep 3: Training Logistic Regression...")
        try:
            logistic_results = train_logistic_model(train_df, val_df, test_df)
            logger.info("Logistic Regression training completed")
        except Exception as e:
            logger.error(f"Logistic Regression training failed: {e}")
            raise

        # 4. Train BiLSTM
        logger.info("\nStep 4: Training BiLSTM...")
        try:
            bilstm_results = train_bilstm_model(train_df, val_df, test_df)
            logger.info("BiLSTM training completed")
        except Exception as e:
            logger.error(f"BiLSTM training failed: {e}")
            raise

        # 5. Train DistilBERT
        logger.info("\nStep 5: Training DistilBERT...")
        try:
            distilbert_results = train_distilbert_model(train_df, val_df, test_df)
            logger.info("DistilBERT training completed")
        except Exception as e:
            logger.error(f"DistilBERT training failed: {e}")
            raise

        # 6. Combine results
        results = {
            "Logistic Regression": logistic_results,
            "BiLSTM": bilstm_results,
            "DistilBERT": distilbert_results,
        }

        # 7. Generate evaluation plots and metrics
        logger.info("\nStep 6: Generating evaluation plots and metrics...")
        try:
            generate_all_evaluation_plots(results)
            logger.info("All evaluation plots and metrics generated")
        except Exception as e:
            logger.error(f"Failed to generate evaluation plots: {e}")
            # Don't fail completely if plotting fails

        # 8. Print summary
        logger.info("\nStep 7: Training Summary")
        summary = create_results_summary(results)
        logger.info(summary)
        print(summary)

        # Save summary to file
        summary_path = config.RESULTS_DIR / "training_summary.txt"
        with open(summary_path, "w") as f:
            f.write(summary)
        logger.info(f"Summary saved to {summary_path}")

        logger.info("\n" + "=" * 80)
        logger.info("TRAINING COMPLETED SUCCESSFULLY")
        logger.info("=" * 80)
        logger.info(f"Results saved to: {config.RESULTS_DIR}")
        logger.info(f"Models saved to: {config.MODEL_DIR}")
        logger.info(f"\nTo start the Flask app, run: python app.py")

        return 0

    except KeyboardInterrupt:
        logger.info("Training interrupted by user")
        return 1
    except Exception as e:
        logger.error(f"Training failed with error: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
