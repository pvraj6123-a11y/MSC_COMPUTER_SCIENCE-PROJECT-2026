"""
Fake News Detection System
Main package initialization
"""

__version__ = "1.0.0"
__author__ = "University Project"
