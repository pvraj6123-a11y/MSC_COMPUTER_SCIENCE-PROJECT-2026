"""
Data loader for fake news detection.
Handles loading, validation, and preprocessing of datasets.
"""

import logging
from pathlib import Path
from typing import Tuple, Optional, Dict, Any
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

logger = logging.getLogger(__name__)


class FakeNewsDataLoader:
    """
    Handles loading and splitting fake news datasets.
    Supports both single CSV format and dual CSV format (Fake.csv, True.csv).
    """

    def __init__(
        self,
        data_dir: Path,
        random_state: int = 42,
        train_size: float = 0.8,
        val_size: float = 0.1,
        test_size: float = 0.1,
        shuffle: bool = True,
        min_text_length: int = 10,
        sample_size: Optional[int] = None,
    ):
        """
        Initialize the data loader.

        Args:
            data_dir: Path to data directory
            random_state: Random seed for reproducibility
            train_size: Proportion for training set
            val_size: Proportion for validation set
            test_size: Proportion for test set
            shuffle: Whether to shuffle data
            min_text_length: Minimum text length to keep
            sample_size: If set, sample this many records (useful for testing)
        """
        self.data_dir = Path(data_dir)
        self.random_state = random_state
        self.train_size = train_size
        self.val_size = val_size
        self.test_size = test_size
        self.shuffle = shuffle
        self.min_text_length = min_text_length
        self.sample_size = sample_size

        # Validate split ratios
        total = train_size + val_size + test_size
        assert abs(total - 1.0) < 1e-6, f"Train+val+test must sum to 1.0, got {total}"

    def load_data(self) -> pd.DataFrame:
        """
        Load dataset from available formats.
        Supports:
        1. Single CSV with 'text' and 'label' columns
        2. Dual CSV format (Fake.csv with label=0, True.csv with label=1)

        Returns:
            DataFrame with 'text' and 'label' columns
        """
        df = None

        # Try to load Fake.csv and True.csv format
        fake_path = self.data_dir / "Fake.csv"
        true_path = self.data_dir / "True.csv"

        if fake_path.exists() and true_path.exists():
            logger.info("Loading dual CSV format (Fake.csv, True.csv)")
            df = self._load_dual_csv(fake_path, true_path)
        else:
            # Try single CSV format
            csv_files = list(self.data_dir.glob("*.csv"))
            if csv_files:
                logger.info(f"Attempting to load single CSV format from {csv_files[0]}")
                df = self._load_single_csv(csv_files[0])
            else:
                raise FileNotFoundError(
                    f"No CSV files found in {self.data_dir}. "
                    "Please place Fake.csv and True.csv or a single CSV file with 'text' and 'label' columns."
                )

        if df is None or len(df) == 0:
            raise ValueError("Failed to load dataset or dataset is empty")

        logger.info(f"Loaded {len(df)} records")
        return df

    def _load_dual_csv(self, fake_path: Path, true_path: Path) -> pd.DataFrame:
        """Load from Fake.csv (label=0) and True.csv (label=1) format."""
        try:
            fake_df = pd.read_csv(fake_path, low_memory=False)
            true_df = pd.read_csv(true_path, low_memory=False)

            # Assign labels
            fake_df["label"] = 0  # FAKE
            true_df["label"] = 1  # REAL

            # Identify text columns
            text_column = self._find_text_column(fake_df)
            if text_column is None:
                text_column = self._find_text_column(true_df)

            if text_column is None:
                raise ValueError("Could not identify text column in CSV files")

            # Extract text columns
            fake_df["text"] = fake_df[text_column].astype(str)
            true_df["text"] = true_df[text_column].astype(str)

            # Combine
            df = pd.concat([fake_df[["text", "label"]], true_df[["text", "label"]]], ignore_index=True)
            logger.info(f"Fake records: {len(fake_df)}, True records: {len(true_df)}")
            return df

        except Exception as e:
            logger.error(f"Error loading dual CSV format: {e}")
            raise

    def _load_single_csv(self, csv_path: Path) -> pd.DataFrame:
        """Load from single CSV format."""
        try:
            df = pd.read_csv(csv_path, low_memory=False)

            # Look for text and label columns
            text_column = self._find_text_column(df)
            label_column = self._find_label_column(df)

            if text_column is None or label_column is None:
                raise ValueError(
                    f"Could not identify required columns. "
                    f"Found columns: {df.columns.tolist()}"
                )

            # Rename to standard columns
            df = df[[text_column, label_column]].copy()
            df.columns = ["text", "label"]

            return df

        except Exception as e:
            logger.error(f"Error loading single CSV: {e}")
            raise

    @staticmethod
    def _find_text_column(df: pd.DataFrame) -> Optional[str]:
        """Identify text column from common names."""
        common_names = ["text", "content", "article", "body", "news", "title"]
        for col in df.columns:
            if col.lower() in common_names:
                return col
        # If no common name found, return the first string column
        for col in df.columns:
            if df[col].dtype == "object":
                return col
        return None

    @staticmethod
    def _find_label_column(df: pd.DataFrame) -> Optional[str]:
        """Identify label column from common names."""
        common_names = ["label", "class", "target", "is_fake", "category"]
        for col in df.columns:
            if col.lower() in common_names:
                return col
        return None

    def preprocess_dataset(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Preprocess the dataset:
        - Remove missing/null text
        - Remove duplicates
        - Normalize labels
        - Remove very short text
        - Shuffle with fixed seed
        """
        initial_count = len(df)
        logger.info(f"Initial dataset size: {initial_count}")

        # Remove missing values
        df = df.dropna(subset=["text", "label"])
        logger.info(f"After removing NaN: {len(df)} records")

        # Remove duplicates (keep first occurrence)
        df = df.drop_duplicates(subset=["text"], keep="first")
        logger.info(f"After removing duplicates: {len(df)} records")

        # Remove very short text
        df = df[df["text"].astype(str).str.len() >= self.min_text_length]
        logger.info(f"After removing short text (<{self.min_text_length} chars): {len(df)} records")

        # Normalize labels to 0/1
        df["label"] = df["label"].astype(int)
        unique_labels = df["label"].unique()
        if len(unique_labels) != 2:
            raise ValueError(f"Expected binary labels, got: {unique_labels}")

        # Map to 0 and 1
        if set(unique_labels) == {0, 1}:
            pass  # Already correct
        elif set(unique_labels) == {1, 2}:
            df["label"] = df["label"] - 1
        else:
            # Map smallest value to 0, largest to 1
            sorted_labels = sorted(unique_labels)
            mapping = {sorted_labels[0]: 0, sorted_labels[1]: 1}
            df["label"] = df["label"].map(mapping)

        # Shuffle
        if self.shuffle:
            df = df.sample(frac=1, random_state=self.random_state).reset_index(drop=True)
            logger.info("Dataset shuffled")

        # Sample if requested
        if self.sample_size:
            df = df.sample(n=min(self.sample_size, len(df)), random_state=self.random_state)
            logger.info(f"Sampled to {len(df)} records (DEBUG mode)")

        # Display class distribution
        class_dist = df["label"].value_counts().sort_index()
        logger.info("Class distribution:")
        for label, count in class_dist.items():
            pct = 100.0 * count / len(df)
            logger.info(f"  Label {label}: {count} ({pct:.1f}%)")

        logger.info(f"Final dataset size: {len(df)}")
        removed = initial_count - len(df)
        logger.info(f"Records removed: {removed}")

        return df

    def split_data(
        self, df: pd.DataFrame
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Split data into train, validation, and test sets.

        Returns:
            Tuple of (train_df, val_df, test_df)
        """
        # First split: train+val vs test
        train_val_df, test_df = train_test_split(
            df,
            test_size=self.test_size,
            random_state=self.random_state,
            stratify=df["label"],
        )

        # Second split: train vs val
        # Adjust val_size relative to train_val set
        val_ratio = self.val_size / (self.train_size + self.val_size)
        train_df, val_df = train_test_split(
            train_val_df,
            test_size=val_ratio,
            random_state=self.random_state,
            stratify=train_val_df["label"],
        )

        logger.info(
            f"Train: {len(train_df)}, "
            f"Validation: {len(val_df)}, "
            f"Test: {len(test_df)}"
        )

        return train_df, val_df, test_df

    def load_and_split(self) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Complete pipeline: load, preprocess, and split dataset.

        Returns:
            Tuple of (train_df, val_df, test_df)
        """
        df = self.load_data()
        df = self.preprocess_dataset(df)
        train_df, val_df, test_df = self.split_data(df)
        return train_df, val_df, test_df
