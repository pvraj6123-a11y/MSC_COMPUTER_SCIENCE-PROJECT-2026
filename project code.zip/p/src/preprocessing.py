"""
Text preprocessing utilities for fake news detection.
Handles cleaning, tokenization, and preparation of text data.
"""

import logging
import re
import string
from typing import List, Optional
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

logger = logging.getLogger(__name__)

# Ensure NLTK resources are available
try:
    stopwords.words("english")
except LookupError:
    logger.info("Downloading NLTK stopwords...")
    nltk.download("stopwords", quiet=True)
    nltk.download("punkt", quiet=True)


class TextPreprocessor:
    """Handles text preprocessing and cleaning."""

    def __init__(
        self,
        lowercase: bool = True,
        remove_urls: bool = True,
        remove_html: bool = True,
        remove_extra_whitespace: bool = True,
        remove_stopwords: bool = True,
    ):
        """
        Initialize text preprocessor.

        Args:
            lowercase: Convert text to lowercase
            remove_urls: Remove URLs from text
            remove_html: Remove HTML tags
            remove_extra_whitespace: Normalize whitespace
            remove_stopwords: Remove English stopwords
        """
        self.lowercase = lowercase
        self.remove_urls = remove_urls
        self.remove_html = remove_html
        self.remove_extra_whitespace = remove_extra_whitespace
        self.remove_stopwords = remove_stopwords
        self.stop_words = set(stopwords.words("english")) if remove_stopwords else set()

    def clean_text(self, text: str) -> str:
        """
        Clean and normalize text.

        Args:
            text: Raw text to clean

        Returns:
            Cleaned text
        """
        if not isinstance(text, str):
            text = str(text)

        # Remove HTML tags
        if self.remove_html:
            text = re.sub(r"<[^>]+>", " ", text)

        # Remove URLs
        if self.remove_urls:
            text = re.sub(r"http\S+|www\S+|https\S+", " ", text, flags=re.MULTILINE)

        # Lowercase
        if self.lowercase:
            text = text.lower()

        # Remove special characters but keep spaces and basic punctuation initially
        text = re.sub(r"[^a-zA-Z0-9\s\'\"]", " ", text)

        # Remove extra whitespace
        if self.remove_extra_whitespace:
            text = " ".join(text.split())

        # Remove stopwords
        if self.remove_stopwords:
            words = text.split()
            words = [w for w in words if w.lower() not in self.stop_words]
            text = " ".join(words)

        # Final whitespace cleanup
        text = " ".join(text.split())

        return text.strip()

    def preprocess(self, text: str) -> str:
        """Alias for clean_text for backwards compatibility."""
        return self.clean_text(text)

    def batch_clean(self, texts: List[str]) -> List[str]:
        """
        Clean multiple texts.

        Args:
            texts: List of texts to clean

        Returns:
            List of cleaned texts
        """
        return [self.clean_text(text) for text in texts]


def normalize_text(text: str) -> str:
    """
    Quick text normalization without stopword removal.
    Useful for DistilBERT which handles its own tokenization.
    """
    if not isinstance(text, str):
        text = str(text)

    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)

    # Remove URLs
    text = re.sub(r"http\S+|www\S+|https\S+", " ", text, flags=re.MULTILINE)

    # Lowercase
    text = text.lower()

    # Remove extra whitespace
    text = " ".join(text.split())

    return text.strip()


def preprocess_for_logistic(texts: List[str]) -> List[str]:
    """Preprocess texts for Logistic Regression (with TF-IDF)."""
    preprocessor = TextPreprocessor(
        lowercase=True,
        remove_urls=True,
        remove_html=True,
        remove_extra_whitespace=True,
        remove_stopwords=True,
    )
    return preprocessor.batch_clean(texts)


def preprocess_for_bilstm(texts: List[str]) -> List[str]:
    """Preprocess texts for BiLSTM (minimal cleaning)."""
    preprocessor = TextPreprocessor(
        lowercase=True,
        remove_urls=True,
        remove_html=True,
        remove_extra_whitespace=True,
        remove_stopwords=False,  # BiLSTM learns from stopwords too
    )
    return preprocessor.batch_clean(texts)


def preprocess_for_distilbert(texts: List[str]) -> List[str]:
    """Preprocess texts for DistilBERT (minimal cleaning, no stopword removal)."""
    # DistilBERT has its own tokenizer, so we just do light normalization
    return [normalize_text(text) for text in texts]
