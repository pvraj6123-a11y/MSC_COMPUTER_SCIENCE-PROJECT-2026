"""
Utility functions for fake news detection system.
"""

import logging
from pathlib import Path
import config

logger = logging.getLogger(__name__)


def setup_logging(level=logging.INFO) -> None:
    """
    Configure logging for the application.

    Args:
        level: Logging level
    """
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    logging.basicConfig(
        level=level,
        format=log_format,
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(config.RESULTS_DIR / "app.log"),
        ],
    )
    logger.info("Logging configured")


def check_models_exist() -> bool:
    """
    Check if all trained models exist.

    Returns:
        True if all models exist, False otherwise
    """
    models_to_check = [
        config.MODEL_PATHS["logistic_model"],
        config.MODEL_PATHS["logistic_vectorizer"],
        config.MODEL_PATHS["bilstm_model"],
        config.MODEL_PATHS["bilstm_tokenizer"],
        config.MODEL_PATHS["distilbert_model"],
    ]

    missing = []
    for model_path in models_to_check:
        if not model_path.exists():
            missing.append(model_path)

    if missing:
        logger.warning(f"Missing model files: {missing}")
        return False

    logger.info("All trained models found")
    return True


def verify_dataset_format(data_dir: Path) -> bool:
    """
    Verify that dataset directory has expected format.

    Args:
        data_dir: Path to data directory

    Returns:
        True if valid dataset found, False otherwise
    """
    if not data_dir.exists():
        logger.error(f"Data directory not found: {data_dir}")
        return False

    # Check for dual CSV format
    fake_csv = data_dir / "Fake.csv"
    true_csv = data_dir / "True.csv"
    
    if fake_csv.exists() and true_csv.exists():
        logger.info("Dual CSV format detected (Fake.csv, True.csv)")
        return True

    # Check for any CSV file
    csv_files = list(data_dir.glob("*.csv"))
    if csv_files:
        logger.info(f"Single CSV format detected: {csv_files[0].name}")
        return True

    logger.error(f"No CSV files found in {data_dir}")
    return False


def create_results_summary(results: dict) -> str:
    """
    Create a text summary of results.

    Args:
        results: Results dictionary from training

    Returns:
        Formatted summary string
    """
    summary = "\n" + "=" * 80 + "\n"
    summary += "FAKE NEWS DETECTION - MODEL EVALUATION SUMMARY\n"
    summary += "=" * 80 + "\n\n"

    for model_name, model_results in results.items():
        summary += f"\n{model_name.upper()}\n"
        summary += "-" * 40 + "\n"

        if "test_metrics" in model_results:
            metrics = model_results["test_metrics"]
            summary += f"  Accuracy:  {metrics.get('accuracy', 0):.4f}\n"
            summary += f"  Precision: {metrics.get('precision', 0):.4f}\n"
            summary += f"  Recall:    {metrics.get('recall', 0):.4f}\n"
            summary += f"  F1-Score:  {metrics.get('f1', 0):.4f}\n"

        if "training_info" in model_results:
            training_info = model_results["training_info"]
            if "training_time" in training_info:
                summary += f"  Training Time: {training_info['training_time']:.2f}s\n"

        if "inference_time" in model_results:
            summary += f"  Inference Time: {model_results['inference_time']*1000:.2f}ms\n"

        if "total_params" in model_results:
            params = model_results["total_params"]
            summary += f"  Model Parameters: {params:,}\n"

    summary += "\n" + "=" * 80 + "\n"
    return summary


def get_model_info() -> dict:
    """
    Get information about available models.

    Returns:
        Dictionary with model information
    """
    info = {
        "Logistic Regression": {
            "description": "Traditional ML baseline using TF-IDF features",
            "parameters": "Uses balanced class weights",
            "training_approach": "Supervised learning with scikit-learn",
        },
        "BiLSTM": {
            "description": "Deep neural network with bidirectional LSTM layers",
            "parameters": "Embedding + BiLSTM + Dense layers",
            "training_approach": "End-to-end neural network training with Keras",
        },
        "DistilBERT": {
            "description": "Transformer-based model using contextual embeddings",
            "parameters": "Pre-trained DistilBERT with classification head",
            "training_approach": "Fine-tuned HuggingFace transformer model",
        },
    }
    return info
