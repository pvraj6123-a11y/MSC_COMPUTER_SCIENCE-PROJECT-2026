"""
Bidirectional LSTM model training for fake news detection.
Uses TensorFlow/Keras for deep learning implementation.
"""

import logging
import time
import pickle
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.layers import (
    Embedding, Bidirectional, LSTM, Dropout, Dense
)
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
from pathlib import Path
from typing import Tuple, Dict, Any, List

import config
from src.preprocessing import preprocess_for_bilstm
from src.evaluate import evaluate_model

logger = logging.getLogger(__name__)

# Set random seeds for reproducibility
np.random.seed(config.RANDOM_STATE)
tf.random.set_seed(config.RANDOM_STATE)


class BiLSTMModel:
    """Bidirectional LSTM model for fake news classification."""

    def __init__(self, config_dict: Dict[str, Any] = None):
        """
        Initialize BiLSTM model configuration.

        Args:
            config_dict: Configuration dictionary
        """
        self.config = config_dict or config.BILSTM_CONFIG
        self.tokenizer = None
        self.model = None
        self.history = None
        self.training_time = None

    def create_tokenizer(self, texts: List[str]) -> Tokenizer:
        """
        Create and fit tokenizer on texts.

        Args:
            texts: List of texts to fit tokenizer on

        Returns:
            Fitted tokenizer
        """
        tokenizer = Tokenizer(
            num_words=self.config["vocab_size"],
            oov_token="<OOV>"
        )
        tokenizer.fit_on_texts(texts)
        logger.info(f"Tokenizer created with vocab size: {len(tokenizer.word_index)}")
        return tokenizer

    def tokenize_and_pad(self, texts: List[str], tokenizer: Tokenizer) -> np.ndarray:
        """
        Convert texts to padded sequences.

        Args:
            texts: List of texts
            tokenizer: Fitted tokenizer

        Returns:
            Padded sequence array
        """
        sequences = tokenizer.texts_to_sequences(texts)
        padded = pad_sequences(
            sequences,
            maxlen=self.config["max_length"],
            padding="post",
            truncating="post"
        )
        return padded

    def build_model(self) -> Sequential:
        """Build BiLSTM model architecture."""
        model = Sequential([
            Embedding(
                input_dim=self.config["vocab_size"],
                output_dim=self.config["embedding_dim"],
                input_length=self.config["max_length"],
                mask_zero=True
            ),
            Bidirectional(LSTM(
                self.config["lstm_units"],
                return_sequences=True,
                dropout=0.2
            )),
            Dropout(self.config["dropout_rate"]),
            Bidirectional(LSTM(self.config["lstm_units"])),
            Dropout(self.config["dropout_rate"]),
            Dense(64, activation="relu"),
            Dropout(self.config["dropout_rate"]),
            Dense(1, activation="sigmoid")
        ])

        optimizer = Adam(learning_rate=self.config["learning_rate"])
        model.compile(
            optimizer=optimizer,
            loss="binary_crossentropy",
            metrics=["accuracy"]
        )

        logger.info("BiLSTM model architecture:")
        model.summary(print_fn=logger.info)

        return model

    def train(
        self,
        X_train: pd.Series,
        y_train: pd.Series,
        X_val: pd.Series,
        y_val: pd.Series,
    ) -> Dict[str, Any]:
        """
        Train BiLSTM model.

        Args:
            X_train: Training texts
            y_train: Training labels
            X_val: Validation texts
            y_val: Validation labels

        Returns:
            Dictionary with training metrics
        """
        logger.info("Training BiLSTM model...")
        start_time = time.time()

        # Preprocess texts
        logger.info("Preprocessing texts...")
        X_train_clean = preprocess_for_bilstm(X_train.tolist())
        X_val_clean = preprocess_for_bilstm(X_val.tolist())

        # Create tokenizer (fit only on training data)
        logger.info("Creating tokenizer...")
        self.tokenizer = self.create_tokenizer(X_train_clean)

        # Tokenize and pad sequences
        logger.info("Tokenizing and padding sequences...")
        X_train_seq = self.tokenize_and_pad(X_train_clean, self.tokenizer)
        X_val_seq = self.tokenize_and_pad(X_val_clean, self.tokenizer)

        y_train_np = y_train.values
        y_val_np = y_val.values

        logger.info(f"Training sequences shape: {X_train_seq.shape}")
        logger.info(f"Validation sequences shape: {X_val_seq.shape}")

        # Build model
        logger.info("Building model...")
        self.model = self.build_model()

        # Define callbacks
        model_dir = config.MODEL_DIRS["bilstm"]
        model_dir.mkdir(parents=True, exist_ok=True)
        checkpoint_path = model_dir / "best_model.keras"

        callbacks = [
            EarlyStopping(
                monitor="val_loss",
                patience=self.config["early_stopping_patience"],
                restore_best_weights=True,
                verbose=1
            ),
            ReduceLROnPlateau(
                monitor="val_loss",
                factor=0.5,
                patience=self.config["reduce_lr_patience"],
                min_lr=1e-6,
                verbose=1
            ),
            ModelCheckpoint(
                str(checkpoint_path),
                monitor="val_accuracy",
                save_best_only=True,
                verbose=1
            )
        ]

        # Train model
        logger.info("Starting training...")
        self.history = self.model.fit(
            X_train_seq,
            y_train_np,
            batch_size=self.config["batch_size"],
            epochs=self.config["epochs"],
            validation_data=(X_val_seq, y_val_np),
            callbacks=callbacks,
            verbose=1
        )

        self.training_time = time.time() - start_time
        logger.info(f"Training completed in {self.training_time:.2f} seconds")

        # Evaluate on validation set
        logger.info("Evaluating on validation set...")
        y_val_pred_proba = self.model.predict(X_val_seq, verbose=0)
        y_val_pred = (y_val_pred_proba.flatten() > 0.5).astype(int)
        val_metrics = evaluate_model(y_val_np, y_val_pred, y_val_pred_proba, model_name="BiLSTM (Validation)")

        return {
            "training_time": self.training_time,
            "validation_metrics": val_metrics,
            "history": self.history.history,
        }

    def predict(self, texts: List[str], verbose: int = 0) -> Tuple[np.ndarray, np.ndarray]:
        """
        Make predictions on texts.

        Args:
            texts: List of texts
            verbose: Verbosity level

        Returns:
            Tuple of (predictions, probabilities)
        """
        if self.tokenizer is None or self.model is None:
            raise ValueError("Model not trained. Call train() first or load model from disk.")

        # Preprocess
        texts_clean = preprocess_for_bilstm(texts)

        # Tokenize and pad
        X_seq = self.tokenize_and_pad(texts_clean, self.tokenizer)

        # Predict
        probabilities = self.model.predict(X_seq, verbose=verbose)
        predictions = (probabilities.flatten() > 0.5).astype(int)

        return predictions, probabilities

    def predict_single(self, text: str) -> Tuple[int, float]:
        """
        Make prediction for single text.

        Args:
            text: Text to predict

        Returns:
            Tuple of (prediction, confidence)
        """
        predictions, probabilities = self.predict([text], verbose=0)
        pred_label = predictions[0]
        confidence = probabilities[0][0]
        return pred_label, float(confidence)

    def save(self, model_dir: Path = None):
        """
        Save model, tokenizer, and config.

        Args:
            model_dir: Directory to save to
        """
        if model_dir is None:
            model_dir = config.MODEL_DIRS["bilstm"]

        model_dir.mkdir(parents=True, exist_ok=True)

        if self.model is None or self.tokenizer is None:
            raise ValueError("Nothing to save. Train model first.")

        # Save model
        model_path = model_dir / "model.keras"
        self.model.save(model_path)
        logger.info(f"Model saved to {model_path}")

        # Save tokenizer
        tokenizer_path = model_dir / "tokenizer.pkl"
        with open(tokenizer_path, "wb") as f:
            pickle.dump(self.tokenizer, f)
        logger.info(f"Tokenizer saved to {tokenizer_path}")

        # Save config
        config_path = model_dir / "config.pkl"
        with open(config_path, "wb") as f:
            pickle.dump(self.config, f)
        logger.info(f"Config saved to {config_path}")

    def load(self, model_dir: Path = None):
        """
        Load model, tokenizer, and config from disk.

        Args:
            model_dir: Directory to load from
        """
        if model_dir is None:
            model_dir = config.MODEL_DIRS["bilstm"]

        model_path = model_dir / "model.keras"
        tokenizer_path = model_dir / "tokenizer.pkl"
        config_path = model_dir / "config.pkl"

        if not model_path.exists():
            raise FileNotFoundError(f"Model not found at {model_path}")

        self.model = keras.models.load_model(model_path)
        logger.info(f"Model loaded from {model_path}")

        if tokenizer_path.exists():
            with open(tokenizer_path, "rb") as f:
                self.tokenizer = pickle.load(f)
            logger.info(f"Tokenizer loaded from {tokenizer_path}")

        if config_path.exists():
            with open(config_path, "rb") as f:
                self.config = pickle.load(f)
            logger.info(f"Config loaded from {config_path}")


def train_bilstm_model(train_df: pd.DataFrame, val_df: pd.DataFrame, test_df: pd.DataFrame):
    """
    Complete training pipeline for BiLSTM.

    Args:
        train_df: Training dataframe
        val_df: Validation dataframe
        test_df: Test dataframe

    Returns:
        Dictionary with results
    """
    model = BiLSTMModel()

    # Train
    training_info = model.train(train_df["text"], train_df["label"], val_df["text"], val_df["label"])

    # Evaluate on test set
    logger.info("Evaluating on test set...")
    y_test = test_df["label"].values
    y_test_pred, y_test_proba = model.predict(test_df["text"].tolist(), verbose=0)
    test_metrics = evaluate_model(y_test, y_test_pred, y_test_proba, model_name="BiLSTM")

    # Calculate inference time
    logger.info("Measuring inference time...")
    start_time = time.time()
    for _ in range(10):
        model.predict_single("Sample text for timing")
    inference_time = (time.time() - start_time) / 10
    logger.info(f"Average inference time: {inference_time*1000:.2f}ms")

    # Save model
    model.save()

    # Count parameters
    total_params = model.model.count_params() if model.model else 0
    trainable_params = sum([tf.size(w).numpy() for w in model.model.trainable_weights]) if model.model else 0
    logger.info(f"Model parameters - Total: {total_params}, Trainable: {trainable_params}")

    results = {
        "model_name": "BiLSTM",
        "model_object": model,
        "training_info": training_info,
        "test_metrics": test_metrics,
        "test_predictions": y_test_pred,
        "test_probabilities": y_test_proba,
        "inference_time": inference_time,
        "y_test_true": y_test,
        "total_params": total_params,
    }

    return results
