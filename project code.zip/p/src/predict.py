"""
Prediction module for fake news detection.
Loads trained models and makes predictions on new texts.
"""

import logging
from typing import Dict, List, Tuple
import numpy as np

import config
from src.train_logistic import LogisticRegressionModel
from src.train_bilstm import BiLSTMModel
from src.train_distilbert import DistilBERTModel

logger = logging.getLogger(__name__)


class FakeNewsPredictorEnsemble:
    """
    Ensemble predictor combining all three models.
    Makes predictions and calculates majority voting.
    """

    def __init__(self):
        """Initialize ensemble with all three models."""
        self.models = {
            "Logistic Regression": LogisticRegressionModel(),
            "BiLSTM": BiLSTMModel(),
            "DistilBERT": DistilBERTModel(),
        }
        self.loaded = False

    def load_all_models(self) -> bool:
        """
        Load all trained models from disk.

        Returns:
            True if all models loaded successfully, False otherwise
        """
        logger.info("Loading trained models...")

        all_loaded = True
        for model_name, model in self.models.items():
            try:
                model.load()
                logger.info(f"{model_name} loaded successfully")
            except Exception as e:
                logger.error(f"Failed to load {model_name}: {e}")
                all_loaded = False

        self.loaded = all_loaded
        return all_loaded

    def predict_logistic(self, text: str) -> Tuple[str, float]:
        """
        Predict using Logistic Regression.

        Args:
            text: Text to predict

        Returns:
            Tuple of (prediction_label, confidence)
        """
        if not self.loaded:
            raise ValueError("Models not loaded. Call load_all_models() first.")

        try:
            pred_label, confidence = self.models["Logistic Regression"].predict_single(text)
            label_str = config.LABEL_MAPPING[pred_label]
            return label_str, float(confidence)
        except Exception as e:
            logger.error(f"Logistic Regression prediction failed: {e}")
            raise

    def predict_bilstm(self, text: str) -> Tuple[str, float]:
        """
        Predict using BiLSTM.

        Args:
            text: Text to predict

        Returns:
            Tuple of (prediction_label, confidence)
        """
        if not self.loaded:
            raise ValueError("Models not loaded. Call load_all_models() first.")

        try:
            pred_label, confidence = self.models["BiLSTM"].predict_single(text)
            label_str = config.LABEL_MAPPING[pred_label]
            return label_str, float(confidence)
        except Exception as e:
            logger.error(f"BiLSTM prediction failed: {e}")
            raise

    def predict_distilbert(self, text: str) -> Tuple[str, float]:
        """
        Predict using DistilBERT.

        Args:
            text: Text to predict

        Returns:
            Tuple of (prediction_label, confidence)
        """
        if not self.loaded:
            raise ValueError("Models not loaded. Call load_all_models() first.")

        try:
            pred_label, confidence = self.models["DistilBERT"].predict_single(text)
            label_str = config.LABEL_MAPPING[pred_label]
            return label_str, float(confidence)
        except Exception as e:
            logger.error(f"DistilBERT prediction failed: {e}")
            raise

    def predict_all(self, text: str) -> Dict[str, Dict[str, any]]:
        """
        Get predictions from all models and majority vote.

        Args:
            text: Text to predict

        Returns:
            Dictionary with predictions from all models and ensemble prediction
        """
        if not self.loaded:
            raise ValueError("Models not loaded. Call load_all_models() first.")

        predictions = {
            "input_text": text[:500],  # Truncate for display
            "predictions": {},
            "majority_prediction": None,
        }

        # Get individual predictions
        votes = []
        try:
            label, conf = self.predict_logistic(text)
            predictions["predictions"]["Logistic Regression"] = {
                "label": label,
                "confidence": conf,
            }
            votes.append(0 if label == "FAKE" else 1)
        except Exception as e:
            logger.warning(f"Logistic Regression prediction failed: {e}")
            predictions["predictions"]["Logistic Regression"] = {"error": str(e)}

        try:
            label, conf = self.predict_bilstm(text)
            predictions["predictions"]["BiLSTM"] = {
                "label": label,
                "confidence": conf,
            }
            votes.append(0 if label == "FAKE" else 1)
        except Exception as e:
            logger.warning(f"BiLSTM prediction failed: {e}")
            predictions["predictions"]["BiLSTM"] = {"error": str(e)}

        try:
            label, conf = self.predict_distilbert(text)
            predictions["predictions"]["DistilBERT"] = {
                "label": label,
                "confidence": conf,
            }
            votes.append(0 if label == "FAKE" else 1)
        except Exception as e:
            logger.warning(f"DistilBERT prediction failed: {e}")
            predictions["predictions"]["DistilBERT"] = {"error": str(e)}

        # Majority vote
        if votes:
            majority_label = 1 if sum(votes) > len(votes) / 2 else 0
            predictions["majority_prediction"] = config.LABEL_MAPPING[majority_label]

        return predictions


def predict_logistic(text: str) -> Dict[str, any]:
    """
    Standalone Logistic Regression prediction.

    Args:
        text: Text to predict

    Returns:
        Prediction result dictionary
    """
    model = LogisticRegressionModel()
    model.load()
    pred_label, confidence = model.predict_single(text)

    return {
        "model": "Logistic Regression",
        "prediction": config.LABEL_MAPPING[pred_label],
        "label": pred_label,
        "confidence": float(confidence),
    }


def predict_bilstm(text: str) -> Dict[str, any]:
    """
    Standalone BiLSTM prediction.

    Args:
        text: Text to predict

    Returns:
        Prediction result dictionary
    """
    model = BiLSTMModel()
    model.load()
    pred_label, confidence = model.predict_single(text)

    return {
        "model": "BiLSTM",
        "prediction": config.LABEL_MAPPING[pred_label],
        "label": pred_label,
        "confidence": float(confidence),
    }


def predict_distilbert(text: str) -> Dict[str, any]:
    """
    Standalone DistilBERT prediction.

    Args:
        text: Text to predict

    Returns:
        Prediction result dictionary
    """
    model = DistilBERTModel()
    model.load()
    pred_label, confidence = model.predict_single(text)

    return {
        "model": "DistilBERT",
        "prediction": config.LABEL_MAPPING[pred_label],
        "label": pred_label,
        "confidence": float(confidence),
    }
