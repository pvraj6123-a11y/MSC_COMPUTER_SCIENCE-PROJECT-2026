"""
Logistic Regression model training for fake news detection.
Uses TF-IDF vectorization for text representation.
"""

import logging
import time
import joblib
from pathlib import Path
from typing import Tuple, Dict, Any
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.utils.class_weight import compute_class_weight

import config
from src.preprocessing import preprocess_for_logistic
from src.evaluate import evaluate_model

logger = logging.getLogger(__name__)


class LogisticRegressionModel:
    """Logistic Regression model for fake news classification."""

    def __init__(self, config_dict: Dict[str, Any] = None):
        """
        Initialize model configuration.

        Args:
            config_dict: Configuration dictionary
        """
        self.config = config_dict or config.LOGISTIC_CONFIG
        self.vectorizer = None
        self.model = None
        self.training_time = None

    def create_vectorizer(self) -> TfidfVectorizer:
        """Create TF-IDF vectorizer with configured parameters."""
        vectorizer = TfidfVectorizer(
            max_features=self.config["tfidf_max_features"],
            ngram_range=self.config["tfidf_ngram_range"],
            min_df=self.config["tfidf_min_df"],
            max_df=self.config["tfidf_max_df"],
            strip_accents="unicode",
            analyzer="word",
            token_pattern=r"\w{1,}",
            lowercase=True,
            stop_words="english",
        )
        return vectorizer

    def train(
        self, X_train: pd.Series, y_train: pd.Series, X_val: pd.Series, y_val: pd.Series
    ) -> Dict[str, Any]:
        """
        Train Logistic Regression model.

        Args:
            X_train: Training texts
            y_train: Training labels
            X_val: Validation texts
            y_val: Validation labels

        Returns:
            Dictionary with training metrics
        """
        logger.info("Training Logistic Regression model...")
        start_time = time.time()

        # Preprocess texts
        logger.info("Preprocessing training texts...")
        X_train_clean = preprocess_for_logistic(X_train.tolist())
        X_val_clean = preprocess_for_logistic(X_val.tolist())

        # Create and fit vectorizer (ONLY on training data)
        logger.info("Creating TF-IDF vectorizer...")
        self.vectorizer = self.create_vectorizer()
        X_train_tfidf = self.vectorizer.fit_transform(X_train_clean)
        logger.info(f"TF-IDF vectorizer created with {len(self.vectorizer.get_feature_names_out())} features")

        # Transform validation data
        X_val_tfidf = self.vectorizer.transform(X_val_clean)

        # Compute class weights if requested
        class_weight = None
        if self.config["use_class_weights"]:
            class_weight = "balanced"
            logger.info("Using balanced class weights")

        # Train model
        logger.info("Training Logistic Regression...")
        self.model = LogisticRegression(
            max_iter=1000,
            random_state=self.config["random_state"],
            class_weight=class_weight,
            n_jobs=-1,
            solver="lbfgs",
        )
        self.model.fit(X_train_tfidf, y_train)

        self.training_time = time.time() - start_time
        logger.info(f"Training completed in {self.training_time:.2f} seconds")

        # Evaluate on validation set
        logger.info("Evaluating on validation set...")
        y_val_pred = self.model.predict(X_val_tfidf)
        val_metrics = evaluate_model(y_val, y_val_pred, model_name="Logistic Regression (Validation)")

        return {
            "training_time": self.training_time,
            "features_count": len(self.vectorizer.get_feature_names_out()),
            "validation_metrics": val_metrics,
        }

    def predict(self, texts: list) -> Tuple[np.ndarray, np.ndarray]:
        """
        Make predictions on new texts.

        Args:
            texts: List of texts to predict

        Returns:
            Tuple of (predictions, probabilities)
        """
        if self.vectorizer is None or self.model is None:
            raise ValueError("Model not trained. Call train() first or load model from disk.")

        # Preprocess
        texts_clean = preprocess_for_logistic(texts)

        # Vectorize
        X_tfidf = self.vectorizer.transform(texts_clean)

        # Predict
        predictions = self.model.predict(X_tfidf)
        probabilities = self.model.predict_proba(X_tfidf)

        return predictions, probabilities

    def predict_single(self, text: str) -> Tuple[int, float]:
        """
        Make prediction for a single text.

        Args:
            text: Text to predict

        Returns:
            Tuple of (prediction, confidence)
        """
        predictions, probabilities = self.predict([text])
        pred_label = predictions[0]
        confidence = max(probabilities[0])
        return pred_label, confidence

    def save(self, model_dir: Path = None):
        """
        Save model and vectorizer to disk.

        Args:
            model_dir: Directory to save models to
        """
        if model_dir is None:
            model_dir = config.MODEL_DIRS["logistic"]

        model_dir.mkdir(parents=True, exist_ok=True)

        if self.model is None or self.vectorizer is None:
            raise ValueError("Nothing to save. Train model first.")

        model_path = model_dir / "model.pkl"
        vectorizer_path = model_dir / "tfidf_vectorizer.pkl"

        joblib.dump(self.model, model_path)
        logger.info(f"Model saved to {model_path}")

        joblib.dump(self.vectorizer, vectorizer_path)
        logger.info(f"Vectorizer saved to {vectorizer_path}")

    def load(self, model_dir: Path = None):
        """
        Load model and vectorizer from disk.

        Args:
            model_dir: Directory to load models from
        """
        if model_dir is None:
            model_dir = config.MODEL_DIRS["logistic"]

        model_path = model_dir / "model.pkl"
        vectorizer_path = model_dir / "tfidf_vectorizer.pkl"

        if not model_path.exists() or not vectorizer_path.exists():
            raise FileNotFoundError(
                f"Model files not found in {model_dir}. "
                f"Expected: {model_path}, {vectorizer_path}"
            )

        self.model = joblib.load(model_path)
        logger.info(f"Model loaded from {model_path}")

        self.vectorizer = joblib.load(vectorizer_path)
        logger.info(f"Vectorizer loaded from {vectorizer_path}")

    def model_size_mb(self) -> float:
        """Get model size in MB."""
        if self.model is None:
            return 0
        return joblib.dump(self.model, "/dev/null") / (1024 * 1024)


def train_logistic_model(train_df: pd.DataFrame, val_df: pd.DataFrame, test_df: pd.DataFrame):
    """
    Complete training pipeline for Logistic Regression.

    Args:
        train_df: Training dataframe
        val_df: Validation dataframe
        test_df: Test dataframe

    Returns:
        Dictionary with results
    """
    model = LogisticRegressionModel()

    # Train
    training_info = model.train(train_df["text"], train_df["label"], val_df["text"], val_df["label"])

    # Evaluate on test set
    logger.info("Evaluating on test set...")
    y_test = test_df["label"].values
    y_test_pred, y_test_proba = model.predict(test_df["text"].tolist())
    test_metrics = evaluate_model(y_test, y_test_pred, y_test_proba, model_name="Logistic Regression")

    # Calculate inference time
    logger.info("Measuring inference time...")
    import time
    start_time = time.time()
    for _ in range(10):
        model.predict_single("Sample text for timing")
    inference_time = (time.time() - start_time) / 10
    logger.info(f"Average inference time: {inference_time*1000:.2f}ms")

    # Save model
    model.save()

    results = {
        "model_name": "Logistic Regression",
        "model_object": model,
        "training_info": training_info,
        "test_metrics": test_metrics,
        "test_predictions": y_test_pred,
        "test_probabilities": y_test_proba,
        "inference_time": inference_time,
        "y_test_true": y_test,
    }

    return results
