"""
DistilBERT model training for fake news detection.
Uses HuggingFace Transformers library for fine-tuning.
"""

import logging
import time
import numpy as np
import pandas as pd
import torch
from pathlib import Path
from typing import Tuple, Dict, Any, List

from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    EvalPrediction,
)
from datasets import Dataset

import config
from src.preprocessing import preprocess_for_distilbert
from src.evaluate import evaluate_model

logger = logging.getLogger(__name__)

# Set seeds
np.random.seed(config.RANDOM_STATE)
torch.manual_seed(config.RANDOM_STATE)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(config.RANDOM_STATE)


class DistilBERTModel:
    """DistilBERT model for fake news classification."""

    def __init__(self, config_dict: Dict[str, Any] = None):
        """
        Initialize DistilBERT model configuration.

        Args:
            config_dict: Configuration dictionary
        """
        self.config = config_dict or config.DISTILBERT_CONFIG
        self.model_name = self.config["model_name"]
        self.tokenizer = None
        self.model = None
        self.training_time = None
        
        # Check if GPU is available
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"Using device: {self.device}")

    def load_tokenizer(self) -> None:
        """Load tokenizer for DistilBERT."""
        logger.info(f"Loading tokenizer for {self.model_name}...")
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        logger.info("Tokenizer loaded successfully")

    def build_model(self) -> None:
        """Load pre-trained DistilBERT model."""
        logger.info(f"Loading pre-trained model {self.model_name}...")
        self.model = AutoModelForSequenceClassification.from_pretrained(
            self.model_name,
            num_labels=2,  # Binary classification
            problem_type="single_label_classification"
        )
        self.model.to(self.device)
        logger.info(f"Model loaded and moved to {self.device}")

    def prepare_datasets(
        self,
        X_train: pd.Series,
        y_train: pd.Series,
        X_val: pd.Series,
        y_val: pd.Series,
        X_test: pd.Series,
        y_test: pd.Series,
    ) -> Tuple[Dataset, Dataset, Dataset]:
        """
        Prepare datasets in HuggingFace Dataset format.

        Args:
            X_train, y_train: Training data
            X_val, y_val: Validation data
            X_test, y_test: Test data

        Returns:
            Tuple of (train_dataset, val_dataset, test_dataset)
        """
        logger.info("Preparing datasets...")

        def tokenize_function(examples):
            return self.tokenizer(
                examples["text"],
                padding="max_length",
                truncation=True,
                max_length=self.config["max_length"],
            )

        # Create datasets
        train_data = {
            "text": preprocess_for_distilbert(X_train.tolist()),
            "label": y_train.tolist(),
        }
        val_data = {
            "text": preprocess_for_distilbert(X_val.tolist()),
            "label": y_val.tolist(),
        }
        test_data = {
            "text": preprocess_for_distilbert(X_test.tolist()),
            "label": y_test.tolist(),
        }

        train_dataset = Dataset.from_dict(train_data)
        val_dataset = Dataset.from_dict(val_data)
        test_dataset = Dataset.from_dict(test_data)

        # Tokenize datasets
        logger.info("Tokenizing datasets...")
        train_dataset = train_dataset.map(tokenize_function, batched=True)
        val_dataset = val_dataset.map(tokenize_function, batched=True)
        test_dataset = test_dataset.map(tokenize_function, batched=True)

        # Set format for PyTorch
        train_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "label"])
        val_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "label"])
        test_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "label"])

        logger.info(f"Datasets prepared - Train: {len(train_dataset)}, Val: {len(val_dataset)}, Test: {len(test_dataset)}")

        return train_dataset, val_dataset, test_dataset

    def compute_metrics(self, eval_pred: EvalPrediction) -> Dict[str, float]:
        """Compute metrics for evaluation."""
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

        predictions, labels = eval_pred
        predictions = np.argmax(predictions, axis=1)

        accuracy = accuracy_score(labels, predictions)
        precision = precision_score(labels, predictions, average="binary")
        recall = recall_score(labels, predictions, average="binary")
        f1 = f1_score(labels, predictions, average="binary")

        return {
            "accuracy": accuracy,
            "precision": precision,
            "recall": recall,
            "f1": f1,
        }

    def train(
        self,
        X_train: pd.Series,
        y_train: pd.Series,
        X_val: pd.Series,
        y_val: pd.Series,
        X_test: pd.Series,
        y_test: pd.Series,
    ) -> Dict[str, Any]:
        """
        Train DistilBERT model.

        Args:
            X_train, y_train: Training data
            X_val, y_val: Validation data
            X_test, y_test: Test data

        Returns:
            Dictionary with training metrics
        """
        logger.info("Starting DistilBERT training...")
        start_time = time.time()

        # Load tokenizer and model
        self.load_tokenizer()
        self.build_model()

        # Prepare datasets
        train_dataset, val_dataset, test_dataset = self.prepare_datasets(
            X_train, y_train, X_val, y_val, X_test, y_test
        )

        # Create output directory
        output_dir = config.MODEL_DIRS["distilbert"]
        output_dir.mkdir(parents=True, exist_ok=True)
        training_dir = output_dir / "training"
        training_dir.mkdir(exist_ok=True)

        # Training arguments
        training_args = TrainingArguments(
            output_dir=str(training_dir),
            num_train_epochs=self.config["epochs"],
            per_device_train_batch_size=self.config["batch_size"],
            per_device_eval_batch_size=self.config["batch_size"],
            learning_rate=self.config["learning_rate"],
            weight_decay=self.config["weight_decay"],
            warmup_steps=self.config["num_warmup_steps"],
            evaluation_strategy="epoch",
            save_strategy="epoch",
            load_best_model_at_end=True,
            metric_for_best_model="f1",
            greater_is_better=True,
            logging_dir=str(training_dir / "logs"),
            logging_steps=100,
            save_total_limit=2,
            seed=config.RANDOM_STATE,
            no_cuda=self.device == "cpu",
            report_to=[],  # Disable wandb/tensorboard reporting
        )

        # Create trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            compute_metrics=self.compute_metrics,
        )

        # Train
        logger.info("Training model...")
        trainer.train()

        self.training_time = time.time() - start_time
        logger.info(f"Training completed in {self.training_time:.2f} seconds")

        # Evaluate on test set
        logger.info("Evaluating on test set...")
        test_results = trainer.evaluate(eval_dataset=test_dataset)
        logger.info(f"Test results: {test_results}")

        # Get predictions
        predictions = trainer.predict(test_dataset)
        y_test_pred = np.argmax(predictions.predictions, axis=1)
        y_test_proba = torch.softmax(torch.tensor(predictions.predictions), dim=1).numpy()

        return {
            "training_time": self.training_time,
            "test_results": test_results,
            "y_test_pred": y_test_pred,
            "y_test_proba": y_test_proba,
        }

    def predict(self, texts: List[str]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Make predictions on texts.

        Args:
            texts: List of texts

        Returns:
            Tuple of (predictions, probabilities)
        """
        if self.tokenizer is None or self.model is None:
            raise ValueError("Model not loaded. Load model from disk first.")

        # Preprocess
        texts_clean = preprocess_for_distilbert(texts)

        # Tokenize
        inputs = self.tokenizer(
            texts_clean,
            padding="max_length",
            truncation=True,
            max_length=self.config["max_length"],
            return_tensors="pt",
        )

        # Move to device
        inputs = {k: v.to(self.device) for k, v in inputs.items()}

        # Predict
        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits

        # Convert to probabilities
        probabilities = torch.softmax(logits, dim=1).cpu().numpy()
        predictions = np.argmax(probabilities, axis=1)

        return predictions, probabilities

    def predict_single(self, text: str) -> Tuple[int, float]:
        """
        Make prediction for single text.

        Args:
            text: Text to predict

        Returns:
            Tuple of (prediction, confidence)
        """
        predictions, probabilities = self.predict([text])
        pred_label = predictions[0]
        confidence = max(probabilities[0])
        return pred_label, float(confidence)

    def save(self, model_dir: Path = None):
        """
        Save model and tokenizer.

        Args:
            model_dir: Directory to save to
        """
        if model_dir is None:
            model_dir = config.MODEL_DIRS["distilbert"]

        model_dir.mkdir(parents=True, exist_ok=True)

        if self.model is None or self.tokenizer is None:
            raise ValueError("Nothing to save. Train model first.")

        # Save model
        self.model.save_pretrained(str(model_dir / "model"))
        logger.info(f"Model saved to {model_dir / 'model'}")

        # Save tokenizer
        self.tokenizer.save_pretrained(str(model_dir / "tokenizer"))
        logger.info(f"Tokenizer saved to {model_dir / 'tokenizer'}")

    def load(self, model_dir: Path = None):
        """
        Load model and tokenizer from disk.

        Args:
            model_dir: Directory to load from
        """
        if model_dir is None:
            model_dir = config.MODEL_DIRS["distilbert"]

        model_path = model_dir / "model"
        tokenizer_path = model_dir / "tokenizer"

        if not model_path.exists():
            raise FileNotFoundError(f"Model not found at {model_path}")

        logger.info(f"Loading model from {model_path}...")
        self.model = AutoModelForSequenceClassification.from_pretrained(str(model_path))
        self.model.to(self.device)
        logger.info(f"Model loaded and moved to {self.device}")

        if tokenizer_path.exists():
            logger.info(f"Loading tokenizer from {tokenizer_path}...")
            self.tokenizer = AutoTokenizer.from_pretrained(str(tokenizer_path))
            logger.info("Tokenizer loaded")


def train_distilbert_model(train_df: pd.DataFrame, val_df: pd.DataFrame, test_df: pd.DataFrame):
    """
    Complete training pipeline for DistilBERT.

    Args:
        train_df: Training dataframe
        val_df: Validation dataframe
        test_df: Test dataframe

    Returns:
        Dictionary with results
    """
    model = DistilBERTModel()

    # Train (includes test evaluation)
    training_info = model.train(
        train_df["text"],
        train_df["label"],
        val_df["text"],
        val_df["label"],
        test_df["text"],
        test_df["label"],
    )

    y_test = test_df["label"].values
    y_test_pred = training_info["y_test_pred"]
    y_test_proba = training_info["y_test_proba"]

    test_metrics = evaluate_model(y_test, y_test_pred, y_test_proba, model_name="DistilBERT")

    # Measure inference time
    logger.info("Measuring inference time...")
    import time
    start_time = time.time()
    for _ in range(10):
        model.predict_single("Sample text for timing")
    inference_time = (time.time() - start_time) / 10
    logger.info(f"Average inference time: {inference_time*1000:.2f}ms")

    # Save model
    model.save()

    # Count parameters
    total_params = sum(p.numel() for p in model.model.parameters())
    trainable_params = sum(p.numel() for p in model.model.parameters() if p.requires_grad)
    logger.info(f"Model parameters - Total: {total_params}, Trainable: {trainable_params}")

    results = {
        "model_name": "DistilBERT",
        "model_object": model,
        "training_info": training_info,
        "test_metrics": test_metrics,
        "test_predictions": y_test_pred,
        "test_probabilities": y_test_proba,
        "inference_time": inference_time,
        "y_test_true": y_test,
        "total_params": total_params,
    }

    return results
