"""
Model evaluation utilities for fake news detection.
Calculates metrics, confusion matrices, and generates visualizations.
"""

import logging
import json
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)

import config

logger = logging.getLogger(__name__)

# Set plotting style
sns.set_style("whitegrid")
plt.rcParams["figure.figsize"] = (12, 6)


def evaluate_model(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: Optional[np.ndarray] = None,
    model_name: str = "Model",
) -> Dict[str, float]:
    """
    Evaluate model performance.

    Args:
        y_true: True labels
        y_pred: Predicted labels
        y_proba: Prediction probabilities (optional)
        model_name: Name of model for logging

    Returns:
        Dictionary with metrics
    """
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average="binary"),
        "recall": recall_score(y_true, y_pred, average="binary"),
        "f1": f1_score(y_true, y_pred, average="binary"),
    }

    logger.info(f"{model_name} Evaluation Metrics:")
    for metric_name, value in metrics.items():
        logger.info(f"  {metric_name.capitalize()}: {value:.4f}")

    return metrics


def generate_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model_name: str = "Model",
    save_path: Optional[Path] = None,
) -> np.ndarray:
    """
    Generate and optionally save confusion matrix.

    Args:
        y_true: True labels
        y_pred: Predicted labels
        model_name: Name of model
        save_path: Path to save figure (optional)

    Returns:
        Confusion matrix array
    """
    cm = confusion_matrix(y_true, y_pred)

    # Plot
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=["FAKE", "REAL"],
        yticklabels=["FAKE", "REAL"],
        cbar=True,
    )
    plt.title(f"Confusion Matrix - {model_name}")
    plt.ylabel("True Label")
    plt.xlabel("Predicted Label")
    plt.tight_layout()

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        logger.info(f"Confusion matrix saved to {save_path}")

    plt.close()

    return cm


def generate_comparison_plot(results: Dict[str, Dict[str, float]], save_path: Optional[Path] = None):
    """
    Generate model comparison plot.

    Args:
        results: Dictionary with model results {model_name: {metric: value}}
        save_path: Path to save figure
    """
    metrics = ["accuracy", "precision", "recall", "f1"]
    models = list(results.keys())

    # Prepare data
    data = {metric: [results[model].get(metric, 0) for model in models] for metric in metrics}

    # Plot
    x = np.arange(len(models))
    width = 0.2

    plt.figure(figsize=(12, 6))
    for i, metric in enumerate(metrics):
        plt.bar(x + i * width, data[metric], width, label=metric.capitalize())

    plt.xlabel("Model")
    plt.ylabel("Score")
    plt.title("Model Performance Comparison")
    plt.xticks(x + width * 1.5, models, rotation=45, ha="right")
    plt.legend()
    plt.ylim([0, 1])
    plt.grid(axis="y", alpha=0.3)
    plt.tight_layout()

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        logger.info(f"Comparison plot saved to {save_path}")

    plt.close()


def plot_training_history(
    history: Dict[str, list],
    model_name: str = "BiLSTM",
    save_path: Optional[Path] = None,
):
    """
    Plot training history (loss and accuracy).

    Args:
        history: Training history dictionary
        model_name: Name of model
        save_path: Path to save figure
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Accuracy plot
    if "accuracy" in history and "val_accuracy" in history:
        axes[0].plot(history["accuracy"], label="Training Accuracy", linewidth=2)
        axes[0].plot(history["val_accuracy"], label="Validation Accuracy", linewidth=2)
        axes[0].set_xlabel("Epoch")
        axes[0].set_ylabel("Accuracy")
        axes[0].set_title(f"{model_name} - Training/Validation Accuracy")
        axes[0].legend()
        axes[0].grid(alpha=0.3)

    # Loss plot
    if "loss" in history and "val_loss" in history:
        axes[1].plot(history["loss"], label="Training Loss", linewidth=2)
        axes[1].plot(history["val_loss"], label="Validation Loss", linewidth=2)
        axes[1].set_xlabel("Epoch")
        axes[1].set_ylabel("Loss")
        axes[1].set_title(f"{model_name} - Training/Validation Loss")
        axes[1].legend()
        axes[1].grid(alpha=0.3)

    plt.tight_layout()

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        logger.info(f"Training history saved to {save_path}")

    plt.close()


def save_metrics_to_json(results: Dict[str, Dict[str, Any]], save_path: Optional[Path] = None):
    """
    Save metrics to JSON file.

    Args:
        results: Dictionary with model results
        save_path: Path to save JSON
    """
    if save_path is None:
        save_path = config.RESULTS_PATHS["metrics_json"]

    save_path.parent.mkdir(parents=True, exist_ok=True)

    # Convert numpy types to Python types
    metrics_data = {}
    for model_name, model_results in results.items():
        metrics_data[model_name] = {}
        if "test_metrics" in model_results:
            for key, value in model_results["test_metrics"].items():
                if isinstance(value, (np.integer, np.floating)):
                    metrics_data[model_name][key] = float(value)
                else:
                    metrics_data[model_name][key] = value

    with open(save_path, "w") as f:
        json.dump(metrics_data, f, indent=4)

    logger.info(f"Metrics saved to {save_path}")


def save_metrics_to_csv(results: Dict[str, Dict[str, Any]], save_path: Optional[Path] = None):
    """
    Save metrics to CSV file.

    Args:
        results: Dictionary with model results
        save_path: Path to save CSV
    """
    if save_path is None:
        save_path = config.RESULTS_PATHS["metrics_csv"]

    save_path.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for model_name, model_results in results.items():
        row = {"Model": model_name}
        if "test_metrics" in model_results:
            for key, value in model_results["test_metrics"].items():
                if isinstance(value, (np.integer, np.floating)):
                    row[key.capitalize()] = float(value)
                else:
                    row[key.capitalize()] = value
        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_csv(save_path, index=False)
    logger.info(f"Metrics saved to {save_path}")

    return df


def save_efficiency_metrics(results: Dict[str, Dict[str, Any]], save_path: Optional[Path] = None):
    """
    Save efficiency comparison metrics.

    Args:
        results: Dictionary with model results
        save_path: Path to save CSV
    """
    if save_path is None:
        save_path = config.RESULTS_PATHS["efficiency_csv"]

    save_path.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for model_name, model_results in results.items():
        row = {"Model": model_name}

        # Add accuracy
        if "test_metrics" in model_results:
            row["Accuracy"] = float(model_results["test_metrics"].get("accuracy", 0))

        # Add inference time
        if "inference_time" in model_results:
            inference_time_ms = model_results["inference_time"] * 1000
            row["Inference Time (ms)"] = f"{inference_time_ms:.2f}"

        # Add training time
        if "training_info" in model_results and "training_time" in model_results["training_info"]:
            training_time_sec = model_results["training_info"]["training_time"]
            row["Training Time (s)"] = f"{training_time_sec:.2f}"

        # Add model parameters
        if "total_params" in model_results:
            params = model_results["total_params"]
            if params > 0:
                row["Model Parameters"] = f"{params:,}"
            else:
                row["Model Parameters"] = "N/A"

        # Add model size if available
        if "model_object" in model_results:
            model_obj = model_results["model_object"]
            try:
                if hasattr(model_obj, "model"):
                    # For neural network models
                    size_mb = sum(p.numel() for p in model_obj.model.parameters()) * 4 / (1024 * 1024)
                    row["Model Size (MB)"] = f"{size_mb:.2f}"
            except:
                row["Model Size (MB)"] = "N/A"

        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_csv(save_path, index=False)
    logger.info(f"Efficiency metrics saved to {save_path}")

    return df


def generate_efficiency_comparison_plot(save_path: Optional[Path] = None):
    """
    Generate efficiency comparison visualization.

    Args:
        save_path: Path to save figure
    """
    csv_path = config.RESULTS_PATHS["efficiency_csv"]
    if not csv_path.exists():
        logger.warning(f"Efficiency metrics CSV not found at {csv_path}")
        return

    df = pd.read_csv(csv_path)

    # This is a placeholder - actual plot would depend on available data
    # For now, we just create a simple table visualization
    plt.figure(figsize=(12, 6))
    plt.axis("off")

    table_data = []
    for _, row in df.iterrows():
        table_data.append(list(row.values))

    table = plt.table(
        cellText=table_data,
        colLabels=df.columns,
        cellLoc="center",
        loc="center",
        bbox=[0, 0, 1, 1],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 2)

    # Style header
    for i in range(len(df.columns)):
        table[(0, i)].set_facecolor("#40466e")
        table[(0, i)].set_text_props(weight="bold", color="white")

    plt.title("Model Efficiency Comparison", fontsize=14, fontweight="bold", pad=20)
    plt.tight_layout()

    if save_path:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        logger.info(f"Efficiency comparison plot saved to {save_path}")

    plt.close()


def generate_all_evaluation_plots(results: Dict[str, Dict[str, Any]]):
    """
    Generate all evaluation plots and save metrics.

    Args:
        results: Dictionary with all model results
    """
    logger.info("Generating evaluation plots and metrics...")

    # Create results directory
    config.RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # Generate comparison plot
    test_metrics = {name: res.get("test_metrics", {}) for name, res in results.items()}
    generate_comparison_plot(test_metrics, config.RESULTS_PATHS["model_comparison"])

    # Generate confusion matrices
    for model_name, model_results in results.items():
        if "y_test_true" in model_results and "test_predictions" in model_results:
            y_true = model_results["y_test_true"]
            y_pred = model_results["test_predictions"]

            # Map model names to file paths
            model_key = model_name.lower().replace(" ", "_")
            if "logistic" in model_key:
                save_path = config.RESULTS_PATHS["confusion_logistic"]
            elif "bilstm" in model_key:
                save_path = config.RESULTS_PATHS["confusion_bilstm"]
            elif "distilbert" in model_key:
                save_path = config.RESULTS_PATHS["confusion_distilbert"]
            else:
                save_path = None

            if save_path:
                generate_confusion_matrix(y_true, y_pred, model_name, save_path)

    # Generate training history if available
    if "BiLSTM" in results and "training_info" in results["BiLSTM"]:
        if "history" in results["BiLSTM"]["training_info"]:
            history = results["BiLSTM"]["training_info"]["history"]
            plot_training_history(history, "BiLSTM", config.RESULTS_PATHS["training_history"])

    # Save metrics
    save_metrics_to_json(results)
    save_metrics_to_csv(results)
    save_efficiency_metrics(results)
    generate_efficiency_comparison_plot(config.RESULTS_PATHS["efficiency_png"])

    logger.info("All evaluation plots and metrics generated successfully")
