# Dataset Directory

## Location

Place your fake news dataset in this directory: `data/`

## Supported Formats

### Option 1: Dual CSV Format (Recommended)

Place two files in this directory:

- **`Fake.csv`** - Articles labeled as FAKE
- **`True.csv`** - Articles labeled as REAL

Each file should have at least one column containing article text. Column names are automatically detected from common patterns.

### Option 2: Single CSV Format

Place a single CSV file in this directory with:

- One column for article text (auto-detected)
- One column for binary label (0 or 1)

## Dataset Structure

### Dual CSV Format Example

**Fake.csv:**
```csv
text,label
"False article about conspiracy...",0
"Another fake news story...",0
...
```

**True.csv:**
```csv
text,label
"Verified news from source...",1
"Breaking news from agency...",1
...
```

### Single CSV Format Example

```csv
text,label
"Article content here...",0
"Another article...",1
"Third article...",1
...
```

## Column Name Detection

The system automatically detects text columns from these common names:
- `text`
- `content`
- `article`
- `body`
- `news`
- `title`

Label columns are detected from:
- `label`
- `class`
- `target`
- `is_fake`
- `category`

## Data Requirements

- **Minimum:** 1,000 articles (recommended: 5,000+)
- **Format:** UTF-8 encoding
- **Labels:** Binary (0/1 or two distinct values)
- **Text Length:** At least 10 characters per article
- **Clean Data:** Remove null/missing values

## Data Preprocessing

The system automatically:

✅ Validates column presence  
✅ Removes missing/null values  
✅ Removes duplicate articles  
✅ Removes very short texts  
✅ Normalizes labels to 0/1  
✅ Displays class distribution  
✅ Shuffles with fixed seed (RANDOM_STATE=42)  
✅ Splits into train/validation/test (80/10/10)  

## Popular Datasets

### Download Options

1. **LIAR Dataset**
   - https://www.cs.ucsb.edu/~william/data/liar_dataset.zip
   - 12.8K news pieces with 6-way classification
   - Use custom preprocessing for binary classification

2. **FakeNewsNet**
   - https://github.com/KaiDMML/FakeNewsNet
   - News articles with source credibility scores
   - Requires conversion to CSV format

3. **MediaEval Fake News Detection**
   - http://www.mediaeval.eu/
   - Research datasets with annotations

4. **Fake and Real News Dataset (Kaggle)**
   - https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset
   - CSV format ready to use
   - ~20K articles

## Format Conversion Examples

### Converting JSON to CSV

```python
import pandas as pd
import json

# Load JSON
with open('news.json') as f:
    data = json.load(f)

# Convert to DataFrame
df = pd.DataFrame(data)

# Save as CSV
df[['text', 'label']].to_csv('data/news.csv', index=False)
```

### Merging Multiple CSV Files

```python
import pandas as pd

df1 = pd.read_csv('news1.csv')
df2 = pd.read_csv('news2.csv')

# Ensure both have 'text' and 'label' columns
combined = pd.concat([df1[['text', 'label']], df2[['text', 'label']]], ignore_index=True)

combined.to_csv('data/combined_news.csv', index=False)
```

### Converting from Database

```python
import pandas as pd
import sqlite3

conn = sqlite3.connect('news.db')
df = pd.read_sql_query("SELECT article_text as text, is_fake as label FROM news", conn)

df.to_csv('data/news_from_db.csv', index=False)
```

## Data Quality Checklist

Before training, verify:

- [ ] CSV files are valid and can be opened
- [ ] Text column contains article content
- [ ] Label column has binary values (0 and 1, or two distinct values)
- [ ] No missing/null values in text or label
- [ ] Text samples are at least 10 characters
- [ ] Character encoding is UTF-8
- [ ] File sizes are reasonable for your system memory
- [ ] You have at least 1,000 articles

## Troubleshooting

### Issue: "No CSV files found in data/"

**Solution:** Ensure CSV file is in this directory:
```bash
ls -la data/
# Should show: Fake.csv and True.csv (or single CSV)
```

### Issue: "Could not identify text column"

**Solution:** Rename your text column to one of: text, content, article, body, news, title

```python
df.rename(columns={'my_article_column': 'text'}, inplace=True)
df.to_csv('data/news.csv', index=False)
```

### Issue: "Expected binary labels, got more than 2 unique values"

**Solution:** Convert labels to 0 and 1:

```python
df['label'] = df['label'].map({'FAKE': 0, 'REAL': 1})
# Or map any two values
df['label'] = df['label'].map({df['label'].unique()[0]: 0, df['label'].unique()[1]: 1})
df.to_csv('data/news.csv', index=False)
```

### Issue: "Out of memory" during training

**Solution:** Use only a subset of data:

Edit `config.py`:
```python
DEBUG_SAMPLE_SIZE = 5000  # Use only 5000 articles for testing
```

Then run:
```bash
python train_all.py  # Will use only 5000 articles
```

## Example Dataset Statistics

After successful data loading, you should see:

```
Initial dataset size: 20000
After removing NaN: 19998
After removing duplicates: 19450
After removing short text: 19400
Dataset split - Train: 15520, Val: 1940, Test: 1940
Class distribution:
  Label 0 (FAKE): 9650 (49.8%)
  Label 1 (REAL): 9750 (50.2%)
```

## Best Practices

1. **Balanced Classes** - Try to have equal FAKE and REAL articles
2. **Representative Sample** - Include diverse news sources and topics
3. **Clean Text** - Remove HTML tags and extra whitespace if possible
4. **Consistent Labels** - Ensure labeling is consistent across files
5. **Backup Original** - Keep original data unmodified
6. **Documentation** - Note the data source and any preprocessing done

## Privacy & Attribution

If using public datasets:

- Credit original dataset creators
- Check dataset license (MIT, CC, etc.)
- Ensure compliance with data usage terms
- Anonymize if containing personal information
- Respect copyright and intellectual property rights

## Next Steps

1. Place CSV file(s) in `data/` directory
2. Run: `python train_all.py`
3. Wait for training to complete (20-40 minutes)
4. Check results: `cat results/metrics.csv`
5. Start dashboard: `python app.py`
6. Open browser: http://localhost:5000

---

For more information, see the main [README.md](../README.md)
