# Fake News Detection System

## Project Overview

This is a comprehensive fake news detection system that implements and compares **three distinct machine learning and deep learning approaches**:

1. **Logistic Regression** - Traditional ML baseline using TF-IDF features
2. **Bidirectional LSTM (BiLSTM)** - Deep neural network with sequential learning
3. **DistilBERT** - Transformer-based model with contextual embeddings

The system classifies news articles as **REAL** or **FAKE** and provides a Flask REST API plus an interactive web dashboard for real-time predictions.

## Research Question

> How do traditional machine learning models compare with deep learning and transformer-based models in detecting fake news, in terms of accuracy, efficiency, and practical usability?

## Objectives

- ✅ Develop a fake-news classification system using multiple ML/DL approaches
- ✅ Compare Logistic Regression, BiLSTM, and DistilBERT performance
- ✅ Evaluate models on: Accuracy, Precision, Recall, F1-Score
- ✅ Measure efficiency: training time, inference time, model size
- ✅ Provide REST API for real-time predictions
- ✅ Create web dashboard for user-friendly interaction
- ✅ Generate confusion matrices and performance comparison plots
- ✅ Ensure reproducibility with fixed random seeds
- ✅ Support CPU and GPU execution

## Key Features

### Three Distinct Models

| Model | Type | Approach | Complexity |
|-------|------|----------|-----------|
| Logistic Regression | Traditional ML | TF-IDF + Linear Classification | Low |
| BiLSTM | Deep Learning | Embedding + Bidirectional LSTM + Dense | Medium |
| DistilBERT | Transformer | Pre-trained HuggingFace + Fine-tuning | High |

### API Endpoints

- `GET /` - Interactive web dashboard
- `GET /api/health` - Health check
- `POST /api/predict` - Get predictions from all three models
- `GET /api/model-info` - Information about available models
- `GET /api/results` - Evaluation results and visualizations

### Outputs

- **Metrics:** Accuracy, Precision, Recall, F1-Score for each model
- **Visualizations:** Confusion matrices, model comparison charts, training history
- **Efficiency Data:** Training time, inference time, model size, parameter counts
- **Saved Models:** Trained weights for all three models (loadable for inference)

## Technologies Used

- **Python 3.8+**
- **scikit-learn** - Logistic Regression & metrics
- **TensorFlow/Keras** - BiLSTM implementation
- **HuggingFace Transformers** - DistilBERT fine-tuning
- **Flask** - REST API and web server
- **NLTK** - Text preprocessing
- **pandas, numpy** - Data handling
- **matplotlib, seaborn** - Visualization
- **PyTorch** - DistilBERT backend

## Project Structure

```
fake_news_detection/
│
├── app.py                      # Flask REST API and web server
├── config.py                   # Configuration and hyperparameters
├── requirements.txt            # Python dependencies
├── train_all.py               # Master training script
├── README.md                   # This file
├── .gitignore                 # Git ignore rules
│
├── data/                       # Dataset directory
│   └── README.md              # Dataset format instructions
│
├── src/                        # Core modules
│   ├── __init__.py
│   ├── data_loader.py         # Dataset loading and preprocessing
│   ├── preprocessing.py       # Text cleaning and tokenization
│   ├── train_logistic.py      # Logistic Regression training
│   ├── train_bilstm.py        # BiLSTM training
│   ├── train_distilbert.py    # DistilBERT training
│   ├── evaluate.py            # Metrics calculation and visualization
│   ├── predict.py             # Inference module
│   └── utils.py               # Utility functions
│
├── models/                     # Trained model storage
│   ├── logistic_regression/
│   │   ├── model.pkl
│   │   └── tfidf_vectorizer.pkl
│   ├── bilstm/
│   │   ├── model.keras
│   │   ├── tokenizer.pkl
│   │   └── config.pkl
│   └── distilbert/
│       ├── model/
│       └── tokenizer/
│
├── templates/                  # Flask templates
│   └── index.html             # Web dashboard HTML
│
├── static/                     # Static files
│   ├── css/
│   │   └── style.css          # Dashboard styling
│   └── js/
│       └── app.js             # Dashboard JavaScript
│
├── results/                    # Generated results
│   ├── metrics.json
│   ├── metrics.csv
│   ├── efficiency_comparison.csv
│   ├── model_comparison.png
│   ├── confusion_matrix_*.png
│   ├── training_history.png
│   └── training_summary.txt
│
├── tests/                      # Test suite
│   ├── test_data_loader.py
│   ├── test_preprocessing.py
│   ├── test_api.py
│   └── test_predict.py
│
└── notebooks/                  # Jupyter notebooks (optional)
    └── experimentation.ipynb
```

## Dataset Requirements

### Supported Formats

The system supports two dataset formats:

#### Option A: Dual CSV Format (Recommended)

Place two files in the `data/` directory:
- `Fake.csv` - Articles labeled as FAKE (label = 0)
- `True.csv` - Articles labeled as REAL (label = 1)

Each CSV should contain at least one column with article text (automatically detected from common names: text, content, article, body, news, title).

#### Option B: Single CSV Format

Place a single CSV file in the `data/` directory with columns:
- `text` or `content` or `article` (text column)
- `label` (binary label: 0 or 1)

### Data Processing

The data loader automatically:
- ✅ Validates required columns
- ✅ Removes missing/null values
- ✅ Removes duplicate articles
- ✅ Filters out very short texts
- ✅ Normalizes labels to 0/1
- ✅ Shuffles with fixed random seed (RANDOM_STATE = 42)
- ✅ Splits into train/val/test (80/10/10)
- ✅ Displays class distribution
- ✅ Reports dataset statistics

## Installation

### Step 1: Clone/Download Project

```bash
cd /path/to/project
```

### Step 2: Create Virtual Environment

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

**Note:** The first `pip install` may take several minutes due to TensorFlow and PyTorch dependencies.

### Step 4: Set Up NLTK Data

NLTK stopwords and tokenizers are downloaded automatically on first use. If you want to pre-download them:

```bash
python -c "
import nltk
nltk.download('stopwords', quiet=True)
nltk.download('punkt', quiet=True)
"
```

## Dataset Setup

### Step 1: Prepare Your Dataset

**Option A: If using Fake.csv and True.csv:**
```bash
mkdir -p data
# Place Fake.csv and True.csv in the data/ directory
```

**Option B: If using a single CSV:**
```bash
mkdir -p data
# Place your_dataset.csv in the data/ directory
```

### Step 2: Verify Dataset Format

The dataset should contain:
- At least 1,000 articles (recommended: 5,000+)
- Binary labels (FAKE/REAL or 0/1)
- Text column with reasonable article length
- No significant class imbalance

Example structure:
```
data/
├── Fake.csv      (columns: title, text, subject, date)
└── True.csv      (columns: title, text, subject, date)
```

## Training

### Step 1: Start Training All Models

```bash
python train_all.py
```

**What happens:**
1. Dataset is loaded from `data/` directory
2. Data is cleaned and split (80/10/10)
3. Logistic Regression is trained and evaluated
4. BiLSTM is trained and evaluated
5. DistilBERT is trained and evaluated (may take 10-30 minutes)
6. All models are saved to `models/` directory
7. Metrics and plots are saved to `results/` directory

**Expected output:**
```
================================================================================
FAKE NEWS DETECTION - MODEL TRAINING
================================================================================

Step 1: Verifying dataset...
Step 2: Loading and preprocessing dataset...
  Initial dataset size: 10000
  Class distribution:
    Label 0: 5000 (50.0%)
    Label 1: 5000 (50.0%)

Step 3: Training Logistic Regression...
  Accuracy: 0.9234
  Precision: 0.9156
  Recall: 0.9312
  F1-Score: 0.9233

Step 4: Training BiLSTM...
  Accuracy: 0.8956
  Precision: 0.8823
  Recall: 0.9089
  F1-Score: 0.8954

Step 5: Training DistilBERT...
  Accuracy: 0.9512
  Precision: 0.9467
  Recall: 0.9557
  F1-Score: 0.9511

Step 6: Generating evaluation plots and metrics...
Step 7: Training Summary

================================================================================
TRAINING COMPLETED SUCCESSFULLY
================================================================================
```

**Training times (approximate):**
- Logistic Regression: 1-2 minutes (on CPU)
- BiLSTM: 5-10 minutes (on CPU), 2-3 minutes (with GPU)
- DistilBERT: 15-30 minutes (on CPU), 5-15 minutes (with GPU)

**Total: 20-40 minutes on CPU, 10-20 minutes with GPU**

### Step 2: Review Results

After training completes, check the results:

```bash
# View metrics
cat results/metrics.csv

# View training summary
cat results/training_summary.txt
```

## Running the Web Dashboard

### Step 1: Start Flask Server

```bash
python app.py
```

**Output:**
```
 * Running on http://127.0.0.1:5000
 * Press CTRL+C to quit
```

### Step 2: Open Dashboard in Browser

Navigate to: **http://localhost:5000**

### Step 3: Use the Dashboard

1. Enter or paste news article text
2. Click "Analyze News"
3. View predictions from all three models
4. See majority vote (ensemble prediction)
5. Review confidence scores for each model

## API Usage

### Health Check

```bash
curl http://localhost:5000/api/health
```

Response:
```json
{
  "status": "healthy",
  "models_loaded": true
}
```

### Make Predictions

```bash
curl -X POST http://localhost:5000/api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Breaking news: Scientists discover new renewable energy source..."
  }'
```

Response:
```json
{
  "success": true,
  "input_text": "Breaking news: Scientists discover...",
  "predictions": {
    "Logistic Regression": {
      "label": "REAL",
      "confidence": 0.95
    },
    "BiLSTM": {
      "label": "REAL",
      "confidence": 0.89
    },
    "DistilBERT": {
      "label": "REAL",
      "confidence": 0.92
    }
  },
  "majority_prediction": "REAL"
}
```

### Get Evaluation Results

```bash
curl http://localhost:5000/api/results
```

Response includes metrics and URLs to visualization images.

## Model Descriptions

### 1. Logistic Regression

**Approach:**
- Text is vectorized using TF-IDF
- Features: unigrams and bigrams, max 10,000 features
- Logistic Regression classifier with balanced class weights
- No stopword removal (preserves signal from all words)

**Advantages:**
- Fast training and inference
- Interpretable features (can see which words matter)
- Baseline for comparison
- Minimal computational requirements

**Limitations:**
- Cannot learn complex non-linear patterns
- TF-IDF may miss semantic meaning
- Sensitive to vocabulary choices

**Files:**
- `models/logistic_regression/model.pkl` - Trained model
- `models/logistic_regression/tfidf_vectorizer.pkl` - Fitted vectorizer

### 2. Bidirectional LSTM (BiLSTM)

**Architecture:**
```
Text → Embedding(100D) → Bidirectional LSTM(64 units) → 
Dropout(0.5) → LSTM(64 units) → Dropout(0.5) → 
Dense(64, ReLU) → Dropout(0.5) → Dense(1, Sigmoid)
```

**Features:**
- Embedding layer learns distributed word representations
- Bidirectional processing captures context from both directions
- Multiple dropout layers prevent overfitting
- Callbacks: EarlyStopping, ReduceLROnPlateau, ModelCheckpoint

**Advantages:**
- Learns sequential patterns in text
- Bidirectional context understanding
- Customizable architecture
- Can capture long-range dependencies (with some limitations)

**Limitations:**
- Slower training than Logistic Regression
- Requires more computational resources
- Can overfit on small datasets
- Less interpretable than TF-IDF

**Files:**
- `models/bilstm/model.keras` - Trained model
- `models/bilstm/tokenizer.pkl` - Fitted Keras tokenizer
- `models/bilstm/config.pkl` - Model configuration

### 3. DistilBERT

**Approach:**
- Uses pre-trained `distilbert-base-uncased` from HuggingFace
- Adds binary classification head on top
- Fine-tuned on the fake news dataset
- Uses HuggingFace Trainer with standard training loop

**Features:**
- Transfer learning from large pre-trained model
- Contextual word embeddings (not static like Word2Vec)
- Handles subword tokenization automatically
- Supports both CPU and GPU training

**Advantages:**
- State-of-the-art performance
- Leverages massive pre-training on 12GB of text
- Handles OOV words through subword tokenization
- Better semantic understanding

**Limitations:**
- Largest model (requires more memory)
- Slowest training time
- Slowest inference
- Requires downloading 268MB pre-trained weights
- May overfit on small datasets

**Files:**
- `models/distilbert/model/` - Trained model weights
- `models/distilbert/tokenizer/` - Tokenizer configuration

## Evaluation Metrics

All models are evaluated on:

### Classification Metrics
- **Accuracy** - Overall correctness (TP+TN)/(TP+TN+FP+FN)
- **Precision** - Correctness of positive predictions TP/(TP+FP)
- **Recall** - Coverage of actual positives TP/(TP+FN)
- **F1-Score** - Harmonic mean of precision and recall

### Visualizations
- **Confusion Matrix** - True vs Predicted labels (separate for each model)
- **Model Comparison Chart** - Side-by-side metric comparison
- **Training History** - BiLSTM loss and accuracy per epoch
- **Efficiency Comparison** - Training time, inference time, model size

### Saved Results
- `results/metrics.json` - Metrics in JSON format
- `results/metrics.csv` - Metrics in CSV format
- `results/efficiency_comparison.csv` - Efficiency metrics
- `results/model_comparison.png` - Comparison chart
- `results/confusion_matrix_*.png` - Confusion matrices (3 files)
- `results/training_history.png` - BiLSTM training curves
- `results/training_summary.txt` - Text summary

## Performance Considerations

### CPU vs GPU

**CPU Execution:**
- Fully supported
- BiLSTM training: ~5-10 minutes (20K records)
- DistilBERT training: ~20-40 minutes (20K records)
- Good for laptops and development

**GPU Execution:**
- Automatically detected and used if available
- CUDA-compatible NVIDIA GPU required
- BiLSTM training: ~2-3 minutes
- DistilBERT training: ~5-15 minutes
- Requires CUDA toolkit and compatible PyTorch/TensorFlow

### Memory Requirements

- **RAM:** 4GB minimum, 8GB recommended
- **Disk:** 2GB for dataset + models + results
- **VRAM:** 2GB minimum for GPU acceleration

### Optimization Tips

1. Reduce dataset size with `DEBUG_SAMPLE_SIZE` in `config.py`
2. Lower `BILSTM_CONFIG["batch_size"]` if running out of memory
3. Reduce `DISTILBERT_CONFIG["max_length"]` (but minimum 128 recommended)
4. Use GPU if available for significant speedup
5. Close other applications to free up RAM

## Testing

Run the test suite:

```bash
python -m pytest tests/ -v
```

**Test Coverage:**
- Data loading and validation
- Text preprocessing
- API request validation
- Model loading from disk
- Prediction accuracy

## Reproducibility

The system uses fixed random seeds to ensure reproducible results:

```python
RANDOM_STATE = 42
```

Applied to:
- NumPy (data splitting)
- TensorFlow (BiLSTM training)
- PyTorch (DistilBERT training)
- sklearn (Logistic Regression)

Running `python train_all.py` multiple times on the same data produces identical results.

## Ethical Considerations

### Key Limitations

1. **Dataset Bias** - Training data may reflect biases in source selection and labeling
2. **Generalization** - Model may not generalize to different news sources or time periods
3. **Not Fact-Checking** - Detects patterns learned from training data, not objective truth
4. **Statistical Patterns** - Model identifies surface-level patterns, not deep reasoning
5. **Potential Harms** - Misclassification could amplify misinformation if used carelessly

### Responsible Use

- ✅ Use as one signal among multiple verification methods
- ✅ Don't rely solely on model predictions for important decisions
- ✅ Consider source credibility independently
- ✅ Check with authoritative fact-checking organizations
- ✅ Understand that absence of evidence of fakeness ≠ proof of truth
- ❌ Don't use to silence or suppress information
- ❌ Don't assume perfect accuracy
- ❌ Don't ignore model limitations in important contexts

### Recommendations

- Combine with manual fact-checking
- Consider multiple independent sources
- Be skeptical of both AI predictions and human judgment
- Understand that AI systems can perpetuate biases
- Respect privacy and don't use for discriminatory purposes

## Limitations

### Model Limitations

1. **Logistic Regression**
   - Cannot learn complex non-linear patterns
   - Highly dependent on TF-IDF feature quality
   - May miss semantic meaning captured by neural models

2. **BiLSTM**
   - Vanishing gradient problem limits long-term dependencies
   - Requires significant computational resources
   - Can overfit on small datasets without careful regularization
   - Less effective than Transformers for very long sequences

3. **DistilBERT**
   - Most computationally expensive
   - May overfit if fine-tuning on small datasets
   - Not interpretable (black box model)
   - Slower inference than traditional ML
   - Pre-training bias may not align with all fake news patterns

### Dataset Limitations

1. **Domain Specificity** - Model trained on specific dataset structure and content
2. **Temporal Validity** - News detection patterns may change over time
3. **Coverage** - May not generalize to all types of news sources
4. **Label Quality** - Depends on accuracy of original labeling
5. **Language** - Only works for English (pre-trained models can be substituted for other languages)

### System Limitations

1. **Maximum Text Length**
   - Logistic Regression: ∞ (vectorizes any text)
   - BiLSTM: 200 tokens (configurable, padded)
   - DistilBERT: 512 tokens (transformer standard limit)

2. **Vocabulary Limitations**
   - Logistic Regression: Limited to training vocabulary
   - BiLSTM: Limited to learned vocab (handles OOV with `<OOV>` token)
   - DistilBERT: Subword tokenization handles most OOV

3. **Scalability**
   - Models handle single articles easily
   - Batch processing available via API
   - Not designed for real-time streaming on high-volume news feeds

## Troubleshooting

### Common Issues

**Issue: "Models not loaded. Run 'python train_all.py' first."**
```
Solution: Train models before starting Flask
$ python train_all.py
$ python app.py
```

**Issue: Out of memory during training**
```
Solution: Reduce dataset size or batch size
Edit config.py:
  DEBUG_SAMPLE_SIZE = 5000  # Use only 5K samples
  BILSTM_CONFIG["batch_size"] = 16  # Reduce from 32
```

**Issue: NLTK stopwords not found**
```
Solution: Download NLTK data
$ python -c "import nltk; nltk.download('stopwords'); nltk.download('punkt')"
```

**Issue: HuggingFace model download fails**
```
Solution: Ensure internet connection, check disk space
Or download manually:
$ python -c "from transformers import AutoTokenizer; AutoTokenizer.from_pretrained('distilbert-base-uncased')"
```

**Issue: TensorFlow/CUDA compatibility**
```
Solution: Use CPU instead (slower but works anywhere)
In config.py: BILSTM_CONFIG["use_cuda"] = False
```

## Contributing

To extend this project:

1. **Add new models** - Create `src/train_[modelname].py`
2. **Change hyperparameters** - Edit `config.py`
3. **Use different dataset** - Place in `data/` directory
4. **Modify frontend** - Edit `templates/index.html` and `static/`
5. **Add new metrics** - Extend `src/evaluate.py`

## References

### Papers & Resources

- Logistic Regression: https://scikit-learn.org/stable/modules/linear_model.html
- BiLSTM: https://colah.github.io/posts/2015-08-Understanding-LSTMs/
- DistilBERT: https://arxiv.org/abs/1910.01108
- BERT: https://arxiv.org/abs/1810.04805
- Fake News Detection: https://www.aclweb.org/anthology/P18-1022/

### Tools Used

- TensorFlow: https://www.tensorflow.org/
- HuggingFace: https://huggingface.co/
- scikit-learn: https://scikit-learn.org/
- Flask: https://flask.palletsprojects.com/

## License

This project is created for educational purposes as a university assignment.

## Authors

University Project - Comparative Fake News Detection Study

## Version

Version 1.0.0 - September 2024

---

**Last Updated:** August 31, 2024

**Python Version:** 3.8+

**Status:** Ready for deployment and evaluation
