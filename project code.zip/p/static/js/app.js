/**
 * Fake News Detection Dashboard - JavaScript Frontend
 * Handles API communication and UI updates
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the dashboard
    initializeDashboard();
    
    // Setup event listeners
    setupEventListeners();
    
    // Load evaluation results if available
    loadEvaluationResults();
    
    // Update status message
    updateStatusMessage();
});

/**
 * Initialize the dashboard
 */
function initializeDashboard() {
    console.log('Initializing Fake News Detection Dashboard');
}

/**
 * Setup event listeners for buttons
 */
function setupEventListeners() {
    const analyzeBtn = document.getElementById('analyzeBtn');
    const clearBtn = document.getElementById('clearBtn');
    const newsTextarea = document.getElementById('newsText');
    
    if (analyzeBtn) {
        analyzeBtn.addEventListener('click', handleAnalyzeClick);
    }
    
    if (clearBtn) {
        clearBtn.addEventListener('click', handleClearClick);
    }
    
    if (newsTextarea) {
        newsTextarea.addEventListener('keydown', function(event) {
            if (event.ctrlKey && event.key === 'Enter') {
                handleAnalyzeClick();
            }
        });
    }
}

/**
 * Handle Analyze button click
 */
function handleAnalyzeClick() {
    const text = document.getElementById('newsText')?.value.trim();
    
    if (!text) {
        showError('Please enter some text to analyze');
        return;
    }
    
    if (text.length < 10) {
        showError('Text must be at least 10 characters long');
        return;
    }
    
    analyzePredictions(text);
}

/**
 * Handle Clear button click
 */
function handleClearClick() {
    document.getElementById('newsText').value = '';
    document.getElementById('resultsSection').classList.add('hidden');
    hideError();
}

/**
 * Update status message based on model availability
 */
function updateStatusMessage() {
    fetch('/api/health')
        .then(response => response.json())
        .then(data => {
            const statusMessage = document.getElementById('statusMessage');
            const statusIcon = document.getElementById('statusIcon');
            const statusText = document.getElementById('statusText');
            
            if (data.models_loaded) {
                statusMessage.className = 'status-message success';
                statusIcon.textContent = '✅';
                statusText.textContent = 'All models loaded and ready for predictions';
            } else {
                statusMessage.className = 'status-message error';
                statusIcon.textContent = '❌';
                statusText.textContent = 'Models not loaded. Please train models first.';
            }
        })
        .catch(error => {
            console.error('Error checking health:', error);
        });
}

/**
 * Send text to API and get predictions
 */
function analyzePredictions(text) {
    const analyzeBtn = document.getElementById('analyzeBtn');
    const spinner = document.getElementById('loadingSpinner');
    
    // Show loading spinner
    spinner.classList.remove('hidden');
    analyzeBtn.disabled = true;
    hideError();
    
    // Update text length
    document.getElementById('textLength').textContent = text.length;
    
    fetch('/api/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: text })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || `HTTP error! status: ${response.status}`);
            });
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            displayPredictions(data);
        } else {
            showError(data.error || 'An error occurred');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showError('Error: ' + error.message);
    })
    .finally(() => {
        spinner.classList.add('hidden');
        analyzeBtn.disabled = false;
    });
}

/**
 * Display predictions on the dashboard
 */
function displayPredictions(data) {
    const resultsSection = document.getElementById('resultsSection');
    
    // Display individual model predictions
    if (data.predictions) {
        displayModelPrediction('Logistic Regression', data.predictions['Logistic Regression']);
        displayModelPrediction('BiLSTM', data.predictions['BiLSTM']);
        displayModelPrediction('DistilBERT', data.predictions['DistilBERT']);
    }
    
    // Display majority prediction
    if (data.majority_prediction) {
        displayEnsemblePrediction(data.majority_prediction);
    }
    
    // Show results section
    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/**
 * Display a single model's prediction
 */
function displayModelPrediction(modelName, prediction) {
    if (!prediction) {
        console.warn(`No prediction for ${modelName}`);
        return;
    }
    
    if (prediction.error) {
        console.error(`Error for ${modelName}:`, prediction.error);
        return;
    }
    
    // Generate model key for HTML IDs
    const modelKey = modelName.toLowerCase().replace(/\s+/g, '-');
    
    // Get DOM elements
    const labelElement = document.getElementById(`${modelKey}-label`);
    const confidenceElement = document.getElementById(`${modelKey}-confidence`);
    const confidenceBar = document.getElementById(`${modelKey}-confidence-bar`);
    
    if (!labelElement || !confidenceElement || !confidenceBar) {
        console.warn(`Could not find elements for ${modelName}`);
        return;
    }
    
    // Update label
    const label = prediction.label || '--';
    labelElement.textContent = label;
    labelElement.className = `prediction-label ${label.toLowerCase()}`;
    
    // Update confidence
    const confidence = (prediction.confidence * 100).toFixed(1);
    confidenceElement.textContent = `${confidence}%`;
    
    // Update confidence bar
    confidenceBar.style.width = `${confidence}%`;
}

/**
 * Display ensemble/majority prediction
 */
function displayEnsemblePrediction(prediction) {
    const ensembleLabel = document.getElementById('ensemble-label');
    
    if (!ensembleLabel) {
        console.warn('Could not find ensemble label element');
        return;
    }
    
    ensembleLabel.textContent = prediction;
    ensembleLabel.className = `ensemble-label ${prediction.toLowerCase()}`;
}

/**
 * Load and display evaluation results
 */
function loadEvaluationResults() {
    fetch('/api/results')
        .then(response => {
            if (!response.ok) {
                throw new Error('Results not available');
            }
            return response.json();
        })
        .then(data => {
            displayEvaluationContent(data);
        })
        .catch(error => {
            console.log('Evaluation results not available yet:', error);
            displayEvaluationNotAvailable();
        });
}

/**
 * Display evaluation results content
 */
function displayEvaluationContent(data) {
    const evaluationContent = document.getElementById('evaluationContent');
    
    if (!evaluationContent) {
        return;
    }
    
    let html = '';
    
    // Display metrics table if available
    if (data.metrics && data.metrics.length > 0) {
        html += '<div class="metrics-table">';
        html += '<h3>Model Performance Metrics</h3>';
        html += '<table style="width: 100%; border-collapse: collapse;">';
        
        // Table header
        html += '<tr style="background-color: #ecf0f1;">';
        html += '<th style="padding: 10px; text-align: left; border: 1px solid #bdc3c7;">Model</th>';
        html += '<th style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">Accuracy</th>';
        html += '<th style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">Precision</th>';
        html += '<th style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">Recall</th>';
        html += '<th style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">F1-Score</th>';
        html += '</tr>';
        
        // Table rows
        data.metrics.forEach(metric => {
            html += '<tr>';
            html += `<td style="padding: 10px; border: 1px solid #bdc3c7;"><strong>${metric.Model}</strong></td>`;
            html += `<td style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">${(metric.Accuracy || 0).toFixed(4)}</td>`;
            html += `<td style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">${(metric.Precision || 0).toFixed(4)}</td>`;
            html += `<td style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">${(metric.Recall || 0).toFixed(4)}</td>`;
            html += `<td style="padding: 10px; text-align: center; border: 1px solid #bdc3c7;">${(metric['F1'] || 0).toFixed(4)}</td>`;
            html += '</tr>';
        });
        
        html += '</table>';
        html += '</div>';
    }
    
    // Display plots if available
    if (data.plots && Object.keys(data.plots).length > 0) {
        html += '<div class="plots-section" style="margin-top: 20px;">';
        html += '<h3>Visualization Plots</h3>';
        
        Object.entries(data.plots).forEach(([name, path]) => {
            html += '<div style="margin: 20px 0;">';
            html += `<h4>${formatPlotName(name)}</h4>`;
            html += `<img src="${path}" alt="${name}" style="max-width: 100%; height: auto; border-radius: 6px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">`;
            html += '</div>';
        });
        
        html += '</div>';
    }
    
    if (html === '') {
        displayEvaluationNotAvailable();
    } else {
        evaluationContent.innerHTML = html;
    }
}

/**
 * Display message when evaluation results are not available
 */
function displayEvaluationNotAvailable() {
    const evaluationContent = document.getElementById('evaluationContent');
    
    if (evaluationContent) {
        evaluationContent.innerHTML = `
            <div style="text-align: center; padding: 30px;">
                <p style="color: #7f8c8d; font-size: 1.1em;">📊 Evaluation results not available yet.</p>
                <p style="color: #95a5a6; margin-top: 10px;">
                    Train the models first by running <code style="background-color: #ecf0f1; padding: 2px 6px; border-radius: 3px;">python train_all.py</code>
                </p>
            </div>
        `;
    }
}

/**
 * Format plot name for display
 */
function formatPlotName(name) {
    const mapping = {
        'comparison': 'Model Comparison',
        'training_history': 'Training History',
        'confusion_logistic': 'Confusion Matrix - Logistic Regression',
        'confusion_bilstm': 'Confusion Matrix - BiLSTM',
        'confusion_distilbert': 'Confusion Matrix - DistilBERT',
        'efficiency': 'Efficiency Comparison'
    };
    
    return mapping[name] || name.replace(/_/g, ' ').toUpperCase();
}

/**
 * Show error message
 */
function showError(message) {
    const errorElement = document.getElementById('errorMessage');
    
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.classList.remove('hidden');
    } else {
        console.error('Error:', message);
    }
}

/**
 * Hide error message
 */
function hideError() {
    const errorElement = document.getElementById('errorMessage');
    
    if (errorElement) {
        errorElement.classList.add('hidden');
    }
}
