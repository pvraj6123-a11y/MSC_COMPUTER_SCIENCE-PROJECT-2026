"""
Configuration file for fake news detection project.
Centralizes all settings and hyperparameters.
"""

import os
from pathlib import Path

# Project directories
PROJECT_DIR = Path(__file__).parent
DATA_DIR = PROJECT_DIR / "data"
MODEL_DIR = PROJECT_DIR / "models"
RESULTS_DIR = PROJECT_DIR / "results"
NOTEBOOKS_DIR = PROJECT_DIR / "notebooks"
TESTS_DIR = PROJECT_DIR / "tests"

# Ensure directories exist
for directory in [DATA_DIR, MODEL_DIR, RESULTS_DIR, NOTEBOOKS_DIR, TESTS_DIR]:
    directory.mkdir(exist_ok=True)

# Random seed for reproducibility
RANDOM_STATE = 42

# Dataset configuration
DATASET_CONFIG = {
    "random_state": RANDOM_STATE,
    "train_size": 0.8,
    "val_size": 0.1,
    "test_size": 0.1,
    "shuffle": True,
    "min_text_length": 10,  # Minimum characters for valid text
}

# Debug/sample mode - set to None for full dataset
DEBUG_SAMPLE_SIZE = None  # Use None for full dataset, or integer for sampling

# Text preprocessing configuration
PREPROCESSING_CONFIG = {
    "lowercase": True,
    "remove_urls": True,
    "remove_html": True,
    "remove_extra_whitespace": True,
    "remove_stopwords": True,
    "min_text_length": 10,
}

# Logistic Regression configuration
LOGISTIC_CONFIG = {
    "tfidf_max_features": 10000,
    "tfidf_ngram_range": (1, 2),
    "tfidf_min_df": 5,
    "tfidf_max_df": 0.8,
    "use_class_weights": True,
    "random_state": RANDOM_STATE,
}

# BiLSTM configuration
BILSTM_CONFIG = {
    "vocab_size": 50000,
    "embedding_dim": 100,
    "max_length": 200,
    "batch_size": 32,
    "epochs": 10,
    "validation_split": 0.1,
    "random_state": RANDOM_STATE,
    "lstm_units": 64,
    "dropout_rate": 0.5,
    "learning_rate": 0.001,
    "early_stopping_patience": 3,
    "reduce_lr_patience": 2,
}

# DistilBERT configuration
DISTILBERT_CONFIG = {
    "model_name": "distilbert-base-uncased",
    "max_length": 512,
    "batch_size": 16,
    "epochs": 3,
    "learning_rate": 2e-5,
    "weight_decay": 0.01,
    "random_state": RANDOM_STATE,
    "num_warmup_steps": 0,
    "use_cuda": True,  # Will use GPU if available
}

# Model directories
MODEL_DIRS = {
    "logistic": MODEL_DIR / "logistic_regression",
    "bilstm": MODEL_DIR / "bilstm",
    "distilbert": MODEL_DIR / "distilbert",
}

# Create model directories
for model_dir in MODEL_DIRS.values():
    model_dir.mkdir(parents=True, exist_ok=True)

# Model file paths
MODEL_PATHS = {
    "logistic_model": MODEL_DIRS["logistic"] / "model.pkl",
    "logistic_vectorizer": MODEL_DIRS["logistic"] / "tfidf_vectorizer.pkl",
    "bilstm_model": MODEL_DIRS["bilstm"] / "model.keras",
    "bilstm_tokenizer": MODEL_DIRS["bilstm"] / "tokenizer.pkl",
    "bilstm_config": MODEL_DIRS["bilstm"] / "config.pkl",
    "distilbert_model": MODEL_DIRS["distilbert"] / "model",
    "distilbert_tokenizer": MODEL_DIRS["distilbert"] / "tokenizer",
}

# Results file paths
RESULTS_PATHS = {
    "metrics_json": RESULTS_DIR / "metrics.json",
    "metrics_csv": RESULTS_DIR / "metrics.csv",
    "efficiency_csv": RESULTS_DIR / "efficiency_comparison.csv",
    "efficiency_png": RESULTS_DIR / "efficiency_comparison.png",
    "model_comparison": RESULTS_DIR / "model_comparison.png",
    "confusion_logistic": RESULTS_DIR / "confusion_matrix_logistic.png",
    "confusion_bilstm": RESULTS_DIR / "confusion_matrix_bilstm.png",
    "confusion_distilbert": RESULTS_DIR / "confusion_matrix_distilbert.png",
    "training_history": RESULTS_DIR / "training_history.png",
}

# Label configuration
LABEL_MAPPING = {
    0: "FAKE",
    1: "REAL",
}

REVERSE_LABEL_MAPPING = {
    "FAKE": 0,
    "REAL": 1,
}

# Flask configuration
FLASK_CONFIG = {
    "host": "127.0.0.1",
    "port": 5000,
    "debug": False,
    "max_content_length": 16 * 1024 * 1024,  # 16MB max request size
}

# API configuration
API_CONFIG = {
    "max_text_length": 10000,  # Maximum characters per prediction
    "timeout": 30,  # Prediction timeout in seconds
}

# Logging configuration
LOGGING_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
}
