"""
Test suite for fake news detection system.
Run with: python -m pytest tests/ -v
"""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
import tempfile
import json

# Tests can import the project modules
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

import config
from src.data_loader import FakeNewsDataLoader
from src.preprocessing import TextPreprocessor, preprocess_for_logistic, preprocess_for_bilstm
from src.predict import FakeNewsPredictorEnsemble


class TestTextPreprocessing:
    """Test text preprocessing functionality."""

    def test_text_preprocessor_init(self):
        """Test TextPreprocessor initialization."""
        preprocessor = TextPreprocessor()
        assert preprocessor is not None
        assert preprocessor.lowercase is True

    def test_clean_text_lowercase(self):
        """Test text lowercase conversion."""
        preprocessor = TextPreprocessor(lowercase=True)
        result = preprocessor.clean_text("HELLO WORLD")
        assert result.isupper() is False

    def test_clean_text_url_removal(self):
        """Test URL removal."""
        preprocessor = TextPreprocessor(remove_urls=True)
        text = "Check this link http://example.com for more info"
        result = preprocessor.clean_text(text)
        assert "http" not in result

    def test_clean_text_html_removal(self):
        """Test HTML tag removal."""
        preprocessor = TextPreprocessor(remove_html=True)
        text = "<p>Hello</p> <b>World</b>"
        result = preprocessor.clean_text(text)
        assert "<" not in result
        assert ">" not in result

    def test_clean_text_empty_string(self):
        """Test handling of empty string."""
        preprocessor = TextPreprocessor()
        result = preprocessor.clean_text("")
        assert isinstance(result, str)

    def test_batch_clean(self):
        """Test batch cleaning."""
        preprocessor = TextPreprocessor()
        texts = ["Hello world", "Test text", "Another example"]
        results = preprocessor.batch_clean(texts)
        assert len(results) == len(texts)
        assert all(isinstance(r, str) for r in results)

    def test_preprocess_for_logistic(self):
        """Test Logistic Regression preprocessing."""
        text = "Check out http://example.com for news!"
        result = preprocess_for_logistic([text])
        assert isinstance(result, list)
        assert len(result) > 0

    def test_preprocess_for_bilstm(self):
        """Test BiLSTM preprocessing."""
        text = "This is test text for BiLSTM"
        result = preprocess_for_bilstm([text])
        assert isinstance(result, list)
        assert len(result) > 0


class TestDataLoader:
    """Test data loader functionality."""

    @pytest.fixture
    def sample_dataframe(self):
        """Create a sample dataframe for testing."""
        return pd.DataFrame({
            "text": [
                "This is a real news article about science",
                "This is fake news spreading false information",
                "Breaking news from reliable source",
                "Misinformation spreading on social media",
                "Scientific study published in journal",
            ] * 20,  # Repeat to get more records
            "label": [1, 0, 1, 0, 1] * 20,  # REAL, FAKE, REAL, FAKE, REAL
        })

    def test_data_loader_init(self):
        """Test DataLoader initialization."""
        loader = FakeNewsDataLoader(
            data_dir=config.DATA_DIR,
            random_state=42,
        )
        assert loader is not None
        assert loader.random_state == 42

    def test_preprocess_dataset_removes_duplicates(self, sample_dataframe):
        """Test that preprocessing removes duplicates."""
        loader = FakeNewsDataLoader(config.DATA_DIR)
        df_with_dups = pd.concat([sample_dataframe, sample_dataframe.iloc[:2]], ignore_index=True)
        
        original_count = len(df_with_dups)
        processed = loader.preprocess_dataset(df_with_dups)
        
        assert len(processed) < original_count  # Should remove duplicates

    def test_preprocess_dataset_normalizes_labels(self, sample_dataframe):
        """Test label normalization."""
        loader = FakeNewsDataLoader(config.DATA_DIR)
        processed = loader.preprocess_dataset(sample_dataframe)
        
        unique_labels = set(processed["label"].unique())
        assert unique_labels == {0, 1}  # Should be binary

    def test_split_data_proportions(self, sample_dataframe):
        """Test data splitting proportions."""
        loader = FakeNewsDataLoader(
            data_dir=config.DATA_DIR,
            train_size=0.8,
            val_size=0.1,
            test_size=0.1,
        )
        
        processed = loader.preprocess_dataset(sample_dataframe)
        train_df, val_df, test_df = loader.split_data(processed)
        
        total = len(train_df) + len(val_df) + len(test_df)
        assert total == len(processed)
        
        # Check approximate proportions
        assert len(train_df) / total >= 0.75  # Should be close to 80%
        assert len(val_df) / total <= 0.15   # Should be close to 10%
        assert len(test_df) / total <= 0.15  # Should be close to 10%


class TestAPIValidation:
    """Test API request validation."""

    def test_health_endpoint_format(self):
        """Test health endpoint returns correct format."""
        # This would require running Flask app
        # Placeholder for integration test
        pass

    def test_predict_request_validation(self):
        """Test prediction request validation."""
        # Test that missing 'text' field is caught
        # Placeholder for integration test
        pass

    def test_predict_empty_text_rejection(self):
        """Test that empty text is rejected."""
        # Placeholder for integration test
        pass

    def test_predict_text_length_limit(self):
        """Test that oversized text is rejected."""
        # Placeholder for integration test
        pass


class TestModelPrediction:
    """Test model prediction functionality."""

    def test_ensemble_predictor_initialization(self):
        """Test FakeNewsPredictorEnsemble initialization."""
        predictor = FakeNewsPredictorEnsemble()
        assert predictor is not None
        assert len(predictor.models) == 3

    def test_ensemble_has_all_models(self):
        """Test ensemble contains all three models."""
        predictor = FakeNewsPredictorEnsemble()
        model_names = list(predictor.models.keys())
        
        assert "Logistic Regression" in model_names
        assert "BiLSTM" in model_names
        assert "DistilBERT" in model_names

    def test_ensemble_loaded_flag_initially_false(self):
        """Test that models are not loaded initially."""
        predictor = FakeNewsPredictorEnsemble()
        assert predictor.loaded is False


class TestConfigurationValidation:
    """Test configuration file."""

    def test_config_has_required_paths(self):
        """Test that config defines required paths."""
        assert hasattr(config, 'DATA_DIR')
        assert hasattr(config, 'MODEL_DIR')
        assert hasattr(config, 'RESULTS_DIR')

    def test_config_has_random_state(self):
        """Test that RANDOM_STATE is defined."""
        assert hasattr(config, 'RANDOM_STATE')
        assert isinstance(config.RANDOM_STATE, int)

    def test_config_has_model_configs(self):
        """Test that model configurations are defined."""
        assert hasattr(config, 'LOGISTIC_CONFIG')
        assert hasattr(config, 'BILSTM_CONFIG')
        assert hasattr(config, 'DISTILBERT_CONFIG')

    def test_label_mappings(self):
        """Test label mapping configuration."""
        assert config.LABEL_MAPPING[0] == "FAKE"
        assert config.LABEL_MAPPING[1] == "REAL"
        assert config.REVERSE_LABEL_MAPPING["FAKE"] == 0
        assert config.REVERSE_LABEL_MAPPING["REAL"] == 1


class TestDirectoryStructure:
    """Test project directory structure."""

    def test_required_directories_exist(self):
        """Test that required directories are created."""
        assert config.DATA_DIR.exists()
        assert config.MODEL_DIR.exists()
        assert config.RESULTS_DIR.exists()

    def test_model_subdirectories_exist(self):
        """Test that model subdirectories exist."""
        for model_dir in config.MODEL_DIRS.values():
            assert model_dir.exists()

    def test_static_files_exist(self):
        """Test that static files are in place."""
        static_dir = Path(__file__).parent.parent / "static"
        templates_dir = Path(__file__).parent.parent / "templates"
        
        assert (static_dir / "css").exists()
        assert (static_dir / "js").exists()
        # Note: HTML files might not exist yet if templates not created


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_preprocess_none_input(self):
        """Test preprocessing with None-like input."""
        preprocessor = TextPreprocessor()
        result = preprocessor.clean_text(None)
        assert isinstance(result, str)

    def test_preprocess_very_long_text(self):
        """Test preprocessing with very long text."""
        preprocessor = TextPreprocessor()
        long_text = "word " * 10000
        result = preprocessor.clean_text(long_text)
        assert isinstance(result, str)

    def test_data_loader_with_invalid_path(self):
        """Test data loader with non-existent path."""
        loader = FakeNewsDataLoader(data_dir=Path("/nonexistent/path"))
        # Should handle gracefully
        assert loader is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
